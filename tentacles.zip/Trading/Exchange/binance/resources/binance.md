Binance is a RestExchange adaptation for Binance exchange using the REST API. 
