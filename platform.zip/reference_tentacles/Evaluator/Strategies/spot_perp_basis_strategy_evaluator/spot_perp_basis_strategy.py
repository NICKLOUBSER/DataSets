#  Drakkar-Software OctoBot-Tentacles
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.
import typing
import numpy as np

import octobot_commons.constants as commons_constants
import octobot_commons.enums as commons_enums
import octobot_commons.evaluators_util as evaluators_util
import octobot_evaluators.api as evaluators_api
import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_trading.api as trading_api


class SpotPerpBasisStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Evaluator for Spot-Perpetual Basis Trading Strategy
    Analyzes basis spread between spot and perpetual futures to identify arbitrage opportunities
    """

    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        self.basis_threshold = 0.30  # Minimum basis percentage for opening position
        self.close_threshold = 0.05  # Minimum basis percentage for closing position
        self.lookback_periods = 20   # Periods to analyze for basis trend

    def init_user_inputs(self, inputs: dict) -> None:
        """
        Initialize user inputs for the evaluator
        """
        super().init_user_inputs(inputs)
        
        self.UI.user_input(
            commons_constants.CONFIG_TENTACLES_REQUIRED_CANDLES_COUNT, 
            commons_enums.UserInputTypes.INT,
            200, inputs, min_val=1,
            title="Initialization candles count: the number of historical candles to fetch from exchanges when OctoBot is starting."
        )
        
        self.UI.user_input(
            "basis_threshold", commons_enums.UserInputTypes.FLOAT,
            self.basis_threshold, inputs, min_val=0.01, max_val=10.0,
            title="Minimum basis percentage threshold for opening positions (0.30 = 0.30%)"
        )
        
        self.UI.user_input(
            "close_threshold", commons_enums.UserInputTypes.FLOAT,
            self.close_threshold, inputs, min_val=0.01, max_val=5.0,
            title="Minimum basis percentage threshold for closing positions (0.05 = 0.05%)"
        )
        
        self.UI.user_input(
            "lookback_periods", commons_enums.UserInputTypes.INT,
            self.lookback_periods, inputs, min_val=5, max_val=100,
            title="Number of periods to analyze for basis trend analysis"
        )

    def get_full_cycle_evaluator_types(self) -> tuple:
        """
        Returns the evaluator types this strategy uses
        """
        return evaluators_enums.EvaluatorMatrixTypes.TA.value, evaluators_enums.EvaluatorMatrixTypes.SCRIPTED.value

    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Main callback for matrix evaluation
        """
        try:
            # Get current market data
            current_price = await self._get_current_price(exchange_name, symbol)
            if current_price is None:
                return

            # Calculate basis spread
            basis_spread = await self._calculate_basis_spread(exchange_name, symbol)
            if basis_spread is None:
                return

            # Analyze basis trend
            basis_trend = await self._analyze_basis_trend(exchange_name, symbol)
            
            # Determine trading signal
            signal_strength = self._calculate_signal_strength(basis_spread, basis_trend)
            
            # Set evaluation note
            self.eval_note = signal_strength
            
            # Complete strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
            
        except Exception as e:
            self.logger.error(f"Error in SpotPerpBasisStrategyEvaluator matrix_callback: {e}")
            self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value

    async def _get_current_price(self, exchange_name: str, symbol: str) -> typing.Optional[float]:
        """
        Get current price for the symbol
        """
        try:
            price_data = trading_api.get_current_candle_val(trading_api.get_exchange_manager(exchange_name), symbol)
            return price_data.get("close") if price_data else None
        except Exception as e:
            self.logger.error(f"Error getting current price for {symbol}: {e}")
            return None

    async def _calculate_basis_spread(self, exchange_name: str, symbol: str) -> typing.Optional[float]:
        """
        Calculate the basis spread between spot and perpetual futures
        For paper trading, we simulate the basis spread
        """
        try:
            # Get spot price
            spot_price = await self._get_current_price(exchange_name, symbol)
            
            if spot_price is None:
                return None
            
            # For paper trading, simulate perpetual price with a small offset
            import random
            import numpy as np
            
            # Simulate basis spread (typically -0.1% to +0.5% for BTC)
            basis_offset = np.random.normal(0.001, 0.002)  # 0.1% mean, 0.2% std
            perp_price = spot_price * (1 + basis_offset)
                
            # Calculate basis as percentage
            basis_spread = ((perp_price - spot_price) / spot_price) * 100
            return basis_spread
            
        except Exception as e:
            self.logger.error(f"Error calculating basis spread: {e}")
            return None

    async def _analyze_basis_trend(self, exchange_name: str, symbol: str) -> typing.Optional[str]:
        """
        Analyze the trend of basis spread over time
        """
        try:
            # Get historical basis data
            historical_basis = await self._get_historical_basis_data(exchange_name, symbol, self.lookback_periods)
            
            if not historical_basis or len(historical_basis) < 5:
                return "neutral"
            
            # Calculate trend using linear regression
            x = np.arange(len(historical_basis))
            y = np.array(historical_basis)
            
            # Simple linear regression
            slope = np.polyfit(x, y, 1)[0]
            
            # Determine trend
            if slope > 0.1:
                return "increasing"
            elif slope < -0.1:
                return "decreasing"
            else:
                return "stable"
                
        except Exception as e:
            self.logger.error(f"Error analyzing basis trend: {e}")
            return "neutral"

    async def _get_historical_basis_data(self, exchange_name: str, symbol: str, periods: int) -> typing.List[float]:
        """
        Get historical basis data for trend analysis
        """
        try:
            # This would typically fetch historical data from the exchange
            # For now, return mock data - in real implementation, fetch from exchange
            return [0.25, 0.28, 0.32, 0.35, 0.30, 0.27, 0.29, 0.33, 0.36, 0.34]
        except Exception as e:
            self.logger.error(f"Error getting historical basis data: {e}")
            return []

    def _calculate_signal_strength(self, basis_spread: float, basis_trend: str) -> float:
        """
        Calculate signal strength based on basis spread and trend
        """
        try:
            # Strong positive signal for high positive basis with increasing trend
            if basis_spread >= self.basis_threshold and basis_trend == "increasing":
                return evaluators_enums.EvaluatorStates.VERY_SHORT.value
            
            # Strong negative signal for high negative basis with decreasing trend
            elif basis_spread <= -self.basis_threshold and basis_trend == "decreasing":
                return evaluators_enums.EvaluatorStates.VERY_LONG.value
            
            # Moderate signals for medium basis spreads
            elif basis_spread >= self.basis_threshold * 0.5:
                return evaluators_enums.EvaluatorStates.SHORT.value
            elif basis_spread <= -self.basis_threshold * 0.5:
                return evaluators_enums.EvaluatorStates.LONG.value
            
            # Close position signals
            elif abs(basis_spread) <= self.close_threshold:
                return evaluators_enums.EvaluatorStates.NEUTRAL.value
            
            # Default neutral
            else:
                return evaluators_enums.EvaluatorStates.NEUTRAL.value
                
        except Exception as e:
            self.logger.error(f"Error calculating signal strength: {e}")
            return evaluators_enums.EvaluatorStates.NEUTRAL.value
