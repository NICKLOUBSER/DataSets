# SpotPerpBasisStrategyEvaluator

## Overview
The SpotPerpBasisStrategyEvaluator analyzes the basis spread between spot and perpetual futures markets to identify arbitrage opportunities.

## Strategy Logic
- **Basis Calculation**: Calculates the percentage difference between spot and perpetual futures prices
- **Trend Analysis**: Analyzes historical basis data to determine trend direction
- **Signal Generation**: Generates trading signals based on basis thresholds and trends

## Configuration Parameters
- `basis_threshold`: Minimum basis percentage for opening positions (default: 0.30%)
- `close_threshold`: Minimum basis percentage for closing positions (default: 0.05%)
- `lookback_periods`: Number of periods for trend analysis (default: 20)

## Trading Signals
- **VERY_SHORT**: High positive basis with increasing trend
- **VERY_LONG**: High negative basis with decreasing trend
- **SHORT**: Moderate positive basis
- **LONG**: Moderate negative basis
- **NEUTRAL**: Basis within close threshold or no clear signal

## Usage
This evaluator is designed to work with the SpotPerpBasisTradingMode for automated basis trading strategies.
