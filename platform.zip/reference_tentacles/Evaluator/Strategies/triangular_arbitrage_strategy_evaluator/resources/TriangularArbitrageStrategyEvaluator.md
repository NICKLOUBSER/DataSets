# TriangularArbitrageStrategyEvaluator

## Overview
The TriangularArbitrageStrategyEvaluator analyzes three-leg arbitrage opportunities between BTC/USDT, ETH/BTC, and ETH/USDT trading pairs.

## Strategy Logic
- **Price Analysis**: Compares actual ETH/USDT price with synthetic price calculated through BTC
- **Profit Calculation**: Calculates net profit after accounting for slippage across three trades
- **Volatility Adjustment**: Adjusts signal strength based on market volatility

## Configuration Parameters
- `min_profit_bps`: Minimum profit threshold in basis points (default: 15 bps = 0.15%)
- `slippage_pct`: Expected slippage percentage per trade (default: 0.10%)
- `lookback_periods`: Number of periods for volatility analysis (default: 10)

## Trading Signals
- **VERY_LONG**: High positive arbitrage opportunity (>2x threshold)
- **LONG**: Positive arbitrage opportunity (>threshold)
- **SHORT**: Negative arbitrage opportunity (<-threshold)
- **VERY_SHORT**: High negative arbitrage opportunity (<-2x threshold)
- **NEUTRAL**: No significant arbitrage opportunity

## Arbitrage Calculation
1. Calculate synthetic ETH/USDT price: ETH/BTC × BTC/USDT
2. Compare with actual ETH/USDT price
3. Account for slippage across three trades
4. Adjust for market volatility

## Usage
This evaluator is designed to work with the TriangularArbitrageTradingMode for automated triangular arbitrage strategies.
