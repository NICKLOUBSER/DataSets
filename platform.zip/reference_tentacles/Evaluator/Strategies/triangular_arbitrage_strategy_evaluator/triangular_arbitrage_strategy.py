#  Drakkar-Software OctoBot-Tentacles
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.
import typing
import numpy as np

import octobot_commons.constants as commons_constants
import octobot_commons.enums as commons_enums
import octobot_commons.evaluators_util as evaluators_util
import octobot_evaluators.api as evaluators_api
import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_trading.api as trading_api


class TriangularArbitrageStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Evaluator for Triangular Arbitrage Strategy
    Analyzes three-leg arbitrage opportunities between BTC/USDT, ETH/BTC, and ETH/USDT pairs
    """

    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        self.min_profit_bps = 15  # Minimum profit in basis points
        self.slippage_pct = 0.10  # Expected slippage percentage
        self.lookback_periods = 10  # Periods to analyze for volatility

    def init_user_inputs(self, inputs: dict) -> None:
        """
        Initialize user inputs for the evaluator
        """
        super().init_user_inputs(inputs)
        
        self.UI.user_input(
            commons_constants.CONFIG_TENTACLES_REQUIRED_CANDLES_COUNT, 
            commons_enums.UserInputTypes.INT,
            200, inputs, min_val=1,
            title="Initialization candles count: the number of historical candles to fetch from exchanges when OctoBot is starting."
        )
        
        self.UI.user_input(
            "min_profit_bps", commons_enums.UserInputTypes.INT,
            self.min_profit_bps, inputs, min_val=1, max_val=1000,
            title="Minimum profit threshold in basis points (15 = 0.15%)"
        )
        
        self.UI.user_input(
            "slippage_pct", commons_enums.UserInputTypes.FLOAT,
            self.slippage_pct, inputs, min_val=0.01, max_val=5.0,
            title="Expected slippage percentage (0.10 = 0.10%)"
        )
        
        self.UI.user_input(
            "lookback_periods", commons_enums.UserInputTypes.INT,
            self.lookback_periods, inputs, min_val=5, max_val=50,
            title="Number of periods to analyze for volatility"
        )

    def get_full_cycle_evaluator_types(self) -> tuple:
        """
        Returns the evaluator types this strategy uses
        """
        return evaluators_enums.EvaluatorMatrixTypes.TA.value, evaluators_enums.EvaluatorMatrixTypes.SCRIPTED.value

    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Main callback for matrix evaluation
        """
        try:
            # Calculate triangular arbitrage opportunity
            arbitrage_opportunity = await self._calculate_triangular_arbitrage(exchange_name)
            if arbitrage_opportunity is None:
                self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return

            # Analyze market volatility
            volatility = await self._analyze_market_volatility(exchange_name)
            
            # Determine trading signal
            signal_strength = self._calculate_signal_strength(arbitrage_opportunity, volatility)
            
            # Set evaluation note
            self.eval_note = signal_strength
            
            # Complete strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
            
        except Exception as e:
            self.logger.error(f"Error in TriangularArbitrageStrategyEvaluator matrix_callback: {e}")
            self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value

    async def _calculate_triangular_arbitrage(self, exchange_name: str) -> typing.Optional[dict]:
        """
        Calculate triangular arbitrage opportunity between BTC/USDT, ETH/BTC, ETH/USDT
        """
        try:
            # Get current prices for all three pairs
            btc_usdt_price = await self._get_current_price(exchange_name, "BTC/USDT")
            eth_btc_price = await self._get_current_price(exchange_name, "ETH/BTC")
            eth_usdt_price = await self._get_current_price(exchange_name, "ETH/USDT")
            
            if None in [btc_usdt_price, eth_btc_price, eth_usdt_price]:
                return None
            
            # Calculate synthetic ETH/USDT price through BTC
            synthetic_eth_usdt = eth_btc_price * btc_usdt_price
            
            # Calculate arbitrage opportunity
            arbitrage_spread = eth_usdt_price - synthetic_eth_usdt
            arbitrage_pct = (arbitrage_spread / synthetic_eth_usdt) * 100
            
            # Calculate profit after slippage
            net_profit_pct = arbitrage_pct - (self.slippage_pct * 3)  # 3 trades
            
            return {
                "arbitrage_spread": arbitrage_spread,
                "arbitrage_pct": arbitrage_pct,
                "net_profit_pct": net_profit_pct,
                "synthetic_price": synthetic_eth_usdt,
                "actual_price": eth_usdt_price
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating triangular arbitrage: {e}")
            return None

    async def _get_current_price(self, exchange_name: str, symbol: str) -> typing.Optional[float]:
        """
        Get current price for the symbol
        """
        try:
            price_data = trading_api.get_current_candle_val(trading_api.get_exchange_manager(exchange_name), symbol)
            return price_data.get("close") if price_data else None
        except Exception as e:
            self.logger.error(f"Error getting current price for {symbol}: {e}")
            return None

    async def _analyze_market_volatility(self, exchange_name: str) -> typing.Optional[float]:
        """
        Analyze market volatility across the three pairs
        """
        try:
            # Get historical data for volatility calculation
            symbols = ["BTC/USDT", "ETH/BTC", "ETH/USDT"]
            volatilities = []
            
            for symbol in symbols:
                volatility = await self._calculate_symbol_volatility(exchange_name, symbol)
                if volatility is not None:
                    volatilities.append(volatility)
            
            if not volatilities:
                return None
                
            # Return average volatility
            return np.mean(volatilities)
            
        except Exception as e:
            self.logger.error(f"Error analyzing market volatility: {e}")
            return None

    async def _calculate_symbol_volatility(self, exchange_name: str, symbol: str) -> typing.Optional[float]:
        """
        Calculate volatility for a specific symbol
        """
        try:
            # Get historical prices (simplified - in real implementation, fetch from exchange)
            historical_prices = await self._get_historical_prices(exchange_name, symbol, self.lookback_periods)
            
            if len(historical_prices) < 2:
                return None
            
            # Calculate returns
            returns = np.diff(np.log(historical_prices))
            
            # Calculate volatility (standard deviation of returns)
            volatility = np.std(returns) * np.sqrt(24)  # Annualized for hourly data
            
            return volatility
            
        except Exception as e:
            self.logger.error(f"Error calculating volatility for {symbol}: {e}")
            return None

    async def _get_historical_prices(self, exchange_name: str, symbol: str, periods: int) -> typing.List[float]:
        """
        Get historical prices for volatility calculation
        """
        try:
            # Mock historical data - in real implementation, fetch from exchange
            base_price = 50000 if "BTC" in symbol else 3000 if "ETH" in symbol else 1
            return [base_price + np.random.normal(0, base_price * 0.01) for _ in range(periods)]
        except Exception as e:
            self.logger.error(f"Error getting historical prices: {e}")
            return []

    def _calculate_signal_strength(self, arbitrage_opportunity: dict, volatility: typing.Optional[float]) -> float:
        """
        Calculate signal strength based on arbitrage opportunity and market volatility
        """
        try:
            net_profit_pct = arbitrage_opportunity["net_profit_pct"]
            net_profit_bps = net_profit_pct * 100  # Convert to basis points
            
            # Adjust for volatility (higher volatility = lower confidence)
            volatility_adjustment = 1.0
            if volatility is not None:
                volatility_adjustment = max(0.5, 1.0 - (volatility * 10))  # Reduce signal strength for high volatility
            
            adjusted_profit_bps = net_profit_bps * volatility_adjustment
            
            # Generate signals based on profit threshold
            if adjusted_profit_bps >= self.min_profit_bps * 2:
                return evaluators_enums.EvaluatorStates.VERY_LONG.value
            elif adjusted_profit_bps >= self.min_profit_bps:
                return evaluators_enums.EvaluatorStates.LONG.value
            elif adjusted_profit_bps <= -self.min_profit_bps:
                return evaluators_enums.EvaluatorStates.SHORT.value
            elif adjusted_profit_bps <= -self.min_profit_bps * 2:
                return evaluators_enums.EvaluatorStates.VERY_SHORT.value
            else:
                return evaluators_enums.EvaluatorStates.NEUTRAL.value
                
        except Exception as e:
            self.logger.error(f"Error calculating signal strength: {e}")
            return evaluators_enums.EvaluatorStates.NEUTRAL.value
