# XemmHedgerStrategyEvaluator

## Overview
The XemmHedgerStrategyEvaluator analyzes cross-exchange price differences to identify hedging opportunities between maker and taker exchanges.

## Strategy Logic
- **Cross-Exchange Analysis**: Compares prices between OKX (maker) and Binance (taker) exchanges
- **Spread Calculation**: Calculates bid-ask spread and net profitability after slippage
- **Stability Analysis**: Analyzes spread stability over time to adjust signal confidence
- **Anti-Hysteresis**: Prevents rapid signal changes with time-based filtering

## Configuration Parameters
- `min_profitability_pct`: Minimum profitability percentage (default: 0.35%)
- `slippage_pct`: Expected slippage percentage per trade (default: 0.08%)
- `anti_hysteresis_sec`: Anti-hysteresis time in seconds (default: 10)
- `lookback_periods`: Number of periods for spread stability analysis (default: 15)

## Trading Signals
- **VERY_LONG**: High positive spread opportunity (>2x threshold)
- **LONG**: Positive spread opportunity (>threshold)
- **SHORT**: Negative spread opportunity (<-threshold)
- **VERY_SHORT**: High negative spread opportunity (<-2x threshold)
- **NEUTRAL**: No significant spread opportunity or anti-hysteresis active

## Spread Calculation
1. Get maker exchange (OKX) bid price
2. Get taker exchange (Binance) ask price
3. Calculate spread percentage
4. Account for slippage across two trades
5. Adjust for spread stability

## Stability Adjustment
- **Very Stable**: 1.2x signal strength
- **Stable**: 1.0x signal strength
- **Moderate**: 0.8x signal strength
- **Volatile**: 0.5x signal strength

## Usage
This evaluator is designed to work with the XemmHedgerTradingMode for automated cross-exchange hedging strategies.
