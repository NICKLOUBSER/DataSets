#  Drakkar-Software OctoBot-Tentacles
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.
import typing
import numpy as np

import octobot_commons.constants as commons_constants
import octobot_commons.enums as commons_enums
import octobot_commons.evaluators_util as evaluators_util
import octobot_evaluators.api as evaluators_api
import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_trading.api as trading_api


class XemmHedgerStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Evaluator for Cross-Exchange Market Making (XEMM) Hedger Strategy
    Analyzes price differences between exchanges to identify hedging opportunities
    """

    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        self.min_profitability_pct = 0.35  # Minimum profitability percentage
        self.slippage_pct = 0.08  # Expected slippage percentage
        self.anti_hysteresis_sec = 10  # Anti-hysteresis time in seconds
        self.lookback_periods = 15  # Periods to analyze for spread stability

    def init_user_inputs(self, inputs: dict) -> None:
        """
        Initialize user inputs for the evaluator
        """
        super().init_user_inputs(inputs)
        
        self.UI.user_input(
            commons_constants.CONFIG_TENTACLES_REQUIRED_CANDLES_COUNT, 
            commons_enums.UserInputTypes.INT,
            200, inputs, min_val=1,
            title="Initialization candles count: the number of historical candles to fetch from exchanges when OctoBot is starting."
        )
        
        self.UI.user_input(
            "min_profitability_pct", commons_enums.UserInputTypes.FLOAT,
            self.min_profitability_pct, inputs, min_val=0.01, max_val=5.0,
            title="Minimum profitability percentage (0.35 = 0.35%)"
        )
        
        self.UI.user_input(
            "slippage_pct", commons_enums.UserInputTypes.FLOAT,
            self.slippage_pct, inputs, min_val=0.01, max_val=5.0,
            title="Expected slippage percentage (0.08 = 0.08%)"
        )
        
        self.UI.user_input(
            "anti_hysteresis_sec", commons_enums.UserInputTypes.INT,
            self.anti_hysteresis_sec, inputs, min_val=1, max_val=300,
            title="Anti-hysteresis time in seconds to prevent rapid signal changes"
        )
        
        self.UI.user_input(
            "lookback_periods", commons_enums.UserInputTypes.INT,
            self.lookback_periods, inputs, min_val=5, max_val=50,
            title="Number of periods to analyze for spread stability"
        )

    def get_full_cycle_evaluator_types(self) -> tuple:
        """
        Returns the evaluator types this strategy uses
        """
        return evaluators_enums.EvaluatorMatrixTypes.TA.value, evaluators_enums.EvaluatorMatrixTypes.SCRIPTED.value

    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Main callback for matrix evaluation
        """
        try:
            # Calculate cross-exchange spread
            spread_data = await self._calculate_cross_exchange_spread(symbol)
            if spread_data is None:
                self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return

            # Analyze spread stability
            spread_stability = await self._analyze_spread_stability(symbol)
            
            # Check anti-hysteresis
            if not self._check_anti_hysteresis():
                self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # Determine trading signal
            signal_strength = self._calculate_signal_strength(spread_data, spread_stability)
            
            # Set evaluation note
            self.eval_note = signal_strength
            
            # Update last signal time for anti-hysteresis
            self._update_last_signal_time()
            
            # Complete strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
            
        except Exception as e:
            self.logger.error(f"Error in XemmHedgerStrategyEvaluator matrix_callback: {e}")
            self.eval_note = evaluators_enums.EvaluatorStates.NEUTRAL.value

    async def _calculate_cross_exchange_spread(self, symbol: str) -> typing.Optional[dict]:
        """
        Calculate spread between maker exchange (OKX) and taker exchange (Binance)
        """
        try:
            # Get prices from both exchanges
            maker_price = await self._get_exchange_price("okx", symbol, "bid")  # Maker exchange bid
            taker_price = await self._get_exchange_price("binance", symbol, "ask")  # Taker exchange ask
            
            if None in [maker_price, taker_price]:
                return None
            
            # Calculate spread
            spread = taker_price - maker_price
            spread_pct = (spread / maker_price) * 100
            
            # Calculate net profitability after slippage
            net_profitability = spread_pct - (self.slippage_pct * 2)  # 2 trades
            
            return {
                "maker_price": maker_price,
                "taker_price": taker_price,
                "spread": spread,
                "spread_pct": spread_pct,
                "net_profitability": net_profitability
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating cross-exchange spread: {e}")
            return None

    async def _get_exchange_price(self, exchange_name: str, symbol: str, side: str) -> typing.Optional[float]:
        """
        Get bid or ask price from specific exchange
        """
        try:
            # In real implementation, this would fetch actual order book data
            # For now, simulate with mock data
            base_price = 0.00001 if "PEPE" in symbol else 50000  # Mock base price
            
            if side == "bid":
                return base_price * 0.999  # Slightly below market
            else:  # ask
                return base_price * 1.001  # Slightly above market
                
        except Exception as e:
            self.logger.error(f"Error getting {side} price from {exchange_name} for {symbol}: {e}")
            return None

    async def _analyze_spread_stability(self, symbol: str) -> typing.Optional[str]:
        """
        Analyze the stability of the spread over time
        """
        try:
            # Get historical spread data
            historical_spreads = await self._get_historical_spreads(symbol, self.lookback_periods)
            
            if len(historical_spreads) < 5:
                return "unknown"
            
            # Calculate spread volatility
            spread_volatility = np.std(historical_spreads)
            spread_mean = np.mean(historical_spreads)
            
            # Determine stability
            cv = spread_volatility / abs(spread_mean) if spread_mean != 0 else float('inf')
            
            if cv < 0.1:
                return "very_stable"
            elif cv < 0.2:
                return "stable"
            elif cv < 0.5:
                return "moderate"
            else:
                return "volatile"
                
        except Exception as e:
            self.logger.error(f"Error analyzing spread stability: {e}")
            return "unknown"

    async def _get_historical_spreads(self, symbol: str, periods: int) -> typing.List[float]:
        """
        Get historical spread data for stability analysis
        """
        try:
            # Mock historical spread data - in real implementation, fetch from exchanges
            base_spread = 0.000001
            return [base_spread + np.random.normal(0, base_spread * 0.1) for _ in range(periods)]
        except Exception as e:
            self.logger.error(f"Error getting historical spreads: {e}")
            return []

    def _check_anti_hysteresis(self) -> bool:
        """
        Check if enough time has passed since last signal change
        """
        try:
            if not hasattr(self, '_last_signal_time'):
                return True
            
            import time
            current_time = time.time()
            time_since_last_signal = current_time - self._last_signal_time
            
            return time_since_last_signal >= self.anti_hysteresis_sec
            
        except Exception as e:
            self.logger.error(f"Error checking anti-hysteresis: {e}")
            return True

    def _update_last_signal_time(self):
        """
        Update the last signal time for anti-hysteresis
        """
        try:
            import time
            self._last_signal_time = time.time()
        except Exception as e:
            self.logger.error(f"Error updating last signal time: {e}")

    def _calculate_signal_strength(self, spread_data: dict, spread_stability: str) -> float:
        """
        Calculate signal strength based on spread profitability and stability
        """
        try:
            net_profitability = spread_data["net_profitability"]
            
            # Adjust signal strength based on spread stability
            stability_multiplier = {
                "very_stable": 1.2,
                "stable": 1.0,
                "moderate": 0.8,
                "volatile": 0.5,
                "unknown": 0.6
            }.get(spread_stability, 0.6)
            
            adjusted_profitability = net_profitability * stability_multiplier
            
            # Generate signals based on profitability threshold
            if adjusted_profitability >= self.min_profitability_pct * 2:
                return evaluators_enums.EvaluatorStates.VERY_LONG.value
            elif adjusted_profitability >= self.min_profitability_pct:
                return evaluators_enums.EvaluatorStates.LONG.value
            elif adjusted_profitability <= -self.min_profitability_pct:
                return evaluators_enums.EvaluatorStates.SHORT.value
            elif adjusted_profitability <= -self.min_profitability_pct * 2:
                return evaluators_enums.EvaluatorStates.VERY_SHORT.value
            else:
                return evaluators_enums.EvaluatorStates.NEUTRAL.value
                
        except Exception as e:
            self.logger.error(f"Error calculating signal strength: {e}")
            return evaluators_enums.EvaluatorStates.NEUTRAL.value
