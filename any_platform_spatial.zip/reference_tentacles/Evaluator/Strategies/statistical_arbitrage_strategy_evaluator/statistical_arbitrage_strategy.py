# Statistical Arbitrage Strategy Evaluator for OctoBot
# Implements pairs trading using cointegration and z-score analysis

import numpy as np
import octobot_commons.constants as commons_constants
import octobot_commons.enums as commons_enums
import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_evaluators.matrix as matrix
import octobot_trading.api as trading_api
from collections import deque


class StatisticalArbitrageStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Statistical arbitrage strategy using pairs trading methodology.
    
    This strategy:
    - Tracks price ratios between two symbols (or single symbol spread)
    - Calculates moving average and standard deviation of the ratio
    - Uses z-score to identify entry/exit opportunities
    - Generates buy/sell signals when spread deviates from mean
    """
    
    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        self.enabled = True
        self.eval_note = commons_constants.START_PENDING_EVAL_NOTE
        self.is_threaded = True
        
        # Strategy parameters (will be set from user inputs)
        self.lookbackPeriod = 100
        self.zScoreEntryThreshold = 2.0
        self.zScoreExitThreshold = 0.5
        self.ratioWindow = 30
        self.minCandlesForCalculation = 50
        
        # Data storage for price ratios
        self.priceRatios = {}  # symbol -> deque of ratios
        self.ratioMeans = {}   # symbol -> current mean
        self.ratioStds = {}    # symbol -> current std
        
        # Pair configuration
        self.pairSymbol = None  # Secondary symbol for pairs trading
        self.usePairsTrading = False
        
    @classmethod
    def get_name(cls) -> str:
        return "StatisticalArbitrageStrategyEvaluator"
    
    @classmethod
    def get_evaluator_type(cls):
        return evaluators_enums.EvaluatorMatrixTypes.STRATEGIES
    
    @classmethod
    def get_default_time_frames(cls) -> list:
        return ["5m", "15m", "1h"]
    
    @classmethod
    def get_required_candles_count(cls) -> int:
        return 200  # Need enough history for statistical analysis
    
    def init_user_inputs(self, inputs: dict) -> None:
        """
        Initialize user-configurable parameters.
        """
        super().init_user_inputs(inputs)
        
        # Safely access UI, fallback to inputs dict if UI is not available
        ui = getattr(self, 'UI', None)
        if ui is None:
            # Fallback: use values from inputs dict or keep defaults
            self.lookbackPeriod = inputs.get("lookback_period", self.lookbackPeriod)
            self.zScoreEntryThreshold = inputs.get("z_score_entry_threshold", self.zScoreEntryThreshold)
            self.zScoreExitThreshold = inputs.get("z_score_exit_threshold", self.zScoreExitThreshold)
            self.ratioWindow = inputs.get("ratio_window", self.ratioWindow)
            self.usePairsTrading = inputs.get("use_pairs_trading", self.usePairsTrading)
            self.pairSymbol = inputs.get("pair_symbol", self.pairSymbol)
            return
        
        self.lookbackPeriod = ui.user_input(
            "lookback_period",
            commons_enums.UserInputTypes.INT,
            100,
            inputs,
            min_val=30,
            max_val=500,
            title="Lookback Period: Number of candles for moving average calculation"
        )
        
        self.zScoreEntryThreshold = ui.user_input(
            "z_score_entry_threshold",
            commons_enums.UserInputTypes.FLOAT,
            2.0,
            inputs,
            min_val=0.5,
            max_val=5.0,
            title="Z-Score Entry Threshold: Enter trade when z-score exceeds this value"
        )
        
        self.zScoreExitThreshold = ui.user_input(
            "z_score_exit_threshold",
            commons_enums.UserInputTypes.FLOAT,
            0.5,
            inputs,
            min_val=0.1,
            max_val=2.0,
            title="Z-Score Exit Threshold: Exit trade when z-score falls below this value"
        )
        
        self.ratioWindow = ui.user_input(
            "ratio_window",
            commons_enums.UserInputTypes.INT,
            30,
            inputs,
            min_val=10,
            max_val=100,
            title="Ratio Window: Number of periods for ratio calculation"
        )
        
        self.usePairsTrading = ui.user_input(
            "use_pairs_trading",
            commons_enums.UserInputTypes.BOOLEAN,
            False,
            inputs,
            title="Enable Pairs Trading: Track ratio between two symbols instead of single symbol spread"
        )
        
        self.pairSymbol = ui.user_input(
            "pair_symbol",
            commons_enums.UserInputTypes.TEXT,
            "",
            inputs,
            title="Pair Symbol: Secondary symbol for pairs trading (e.g., BTC/USDT if main is ETH/USDT)"
        )
    
    def _get_price_ratio(self, exchange_manager, symbol, time_frame):
        """
        Calculate price ratio for statistical arbitrage.
        For pairs trading: ratio = symbol_price / pair_symbol_price
        For single symbol: ratio = current_price / moving_average
        """
        try:
            symbol_data = trading_api.get_symbol_data(exchange_manager, symbol, allow_creation=False)
            if symbol_data is None:
                return None
            
            historical_candles = trading_api.get_symbol_historical_candles(
                symbol_data, time_frame, limit=self.lookbackPeriod
            )
            
            if historical_candles is None or len(historical_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value]) < self.minCandlesForCalculation:
                return None
            
            closes = historical_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value]
            current_price = closes[-1]
            
            if self.usePairsTrading and self.pairSymbol:
                # Pairs trading: calculate ratio between two symbols
                pair_symbol_data = trading_api.get_symbol_data(
                    exchange_manager, self.pairSymbol, allow_creation=False
                )
                if pair_symbol_data is None:
                    return None
                
                pair_candles = trading_api.get_symbol_historical_candles(
                    pair_symbol_data, time_frame, limit=self.lookbackPeriod
                )
                if pair_candles is None:
                    return None
                
                pair_closes = pair_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value]
                if len(pair_closes) < len(closes):
                    return None
                
                # Align arrays
                min_len = min(len(closes), len(pair_closes))
                closes = closes[-min_len:]
                pair_closes = pair_closes[-min_len:]
                
                # Calculate ratio
                ratios = closes / pair_closes
                return ratios[-1], ratios
            else:
                # Single symbol: use price relative to moving average
                if len(closes) < self.ratioWindow:
                    return None
                
                # Calculate ratio as current price / moving average
                ma = np.mean(closes[-self.ratioWindow:])
                current_ratio = current_price / ma if ma > 0 else 1.0
                
                # Calculate historical ratios for z-score
                ratios = []
                for i in range(self.ratioWindow, len(closes)):
                    window_ma = np.mean(closes[i-self.ratioWindow:i])
                    if window_ma > 0:
                        ratios.append(closes[i] / window_ma)
                
                return current_ratio, np.array(ratios) if ratios else None
                
        except Exception as e:
            self.logger.error(f"Error calculating price ratio for {symbol}: {e}")
            return None
    
    def _calculate_z_score(self, current_ratio, historical_ratios):
        """
        Calculate z-score of current ratio relative to historical distribution.
        """
        if historical_ratios is None or len(historical_ratios) < self.minCandlesForCalculation:
            return None
        
        mean_ratio = np.mean(historical_ratios)
        std_ratio = np.std(historical_ratios)
        
        if std_ratio == 0:
            return None
        
        z_score = (current_ratio - mean_ratio) / std_ratio
        return z_score, mean_ratio, std_ratio
    
    def _generate_signal(self, z_score):
        """
        Generate trading signal based on z-score.
        Returns: -1.0 (strong sell) to 1.0 (strong buy), 0.0 (neutral)
        """
        if z_score is None:
            return 0.0
        
        z_value = z_score[0] if isinstance(z_score, tuple) else z_score
        
        # Strong buy signal: ratio is too low (z-score is very negative)
        # Normalize to -1.0 when z-score is at entry threshold
        if z_value <= -self.zScoreEntryThreshold:
            # Scale signal strength based on how far z-score deviates
            signal_strength = min(abs(z_value) / self.zScoreEntryThreshold, 2.0) / 2.0
            return -signal_strength  # Negative z-score = buy signal (ratio too low)
        
        # Strong sell signal: ratio is too high (z-score is very positive)
        elif z_value >= self.zScoreEntryThreshold:
            # Scale signal strength based on how far z-score deviates
            signal_strength = min(z_value / self.zScoreEntryThreshold, 2.0) / 2.0
            return signal_strength  # Positive z-score = sell signal (ratio too high)
        
        # Exit signal: ratio has converged back to mean
        elif abs(z_value) <= self.zScoreExitThreshold:
            return 0.0
        
        # Gradual signal for values between thresholds
        # Linear interpolation between exit and entry thresholds
        if z_value < 0:
            # Between -entry and -exit: gradual buy signal
            progress = (abs(z_value) - self.zScoreExitThreshold) / (self.zScoreEntryThreshold - self.zScoreExitThreshold)
            return -progress * 0.5  # Max -0.5 for gradual signals
        else:
            # Between exit and entry: gradual sell signal
            progress = (z_value - self.zScoreExitThreshold) / (self.zScoreEntryThreshold - self.zScoreExitThreshold)
            return progress * 0.5  # Max 0.5 for gradual signals
    
    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Main strategy evaluation callback.
        """
        try:
            # Get exchange manager
            exchange_id = trading_api.get_exchange_id_from_matrix_id(exchange_name, matrix_id)
            exchange_manager = trading_api.get_exchange_manager_from_exchange_id(exchange_id)
            
            if exchange_manager is None:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # Calculate price ratio
            ratio_result = self._get_price_ratio(exchange_manager, symbol, time_frame)
            
            if ratio_result is None:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            current_ratio, historical_ratios = ratio_result
            
            if historical_ratios is None or len(historical_ratios) < self.minCandlesForCalculation:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # Calculate z-score
            z_score_result = self._calculate_z_score(current_ratio, historical_ratios)
            
            if z_score_result is None:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            z_score, mean_ratio, std_ratio = z_score_result
            
            # Store statistics for this symbol
            symbol_key = f"{symbol}_{time_frame.value}"
            if symbol_key not in self.priceRatios:
                self.priceRatios[symbol_key] = deque(maxlen=self.lookbackPeriod)
            
            self.priceRatios[symbol_key].append(current_ratio)
            self.ratioMeans[symbol_key] = mean_ratio
            self.ratioStds[symbol_key] = std_ratio
            
            # Generate signal
            signal = self._generate_signal(z_score)
            self.eval_note = signal
            
            # Log for debugging
            self.logger.debug(
                f"StatisticalArbitrage: {symbol} | Z-Score: {z_score:.3f} | "
                f"Ratio: {current_ratio:.6f} | Mean: {mean_ratio:.6f} | "
                f"Std: {std_ratio:.6f} | Signal: {signal}"
            )
            
            # Complete strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
            
        except Exception as e:
            self.logger.error(f"Error in StatisticalArbitrageStrategyEvaluator matrix_callback: {e}")
            self.eval_note = 0.0
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)

