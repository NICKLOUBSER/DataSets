Uses the [Moving Average Convergence Divergence](https://www.investopedia.com/terms/m/macd.asp) to find reversals.

This evaluator will try to find patterns in the [MACD](https://www.investopedia.com/terms/m/macd.asp) histogram and returns -1 to 1 according to the price and identified pattern strength.
