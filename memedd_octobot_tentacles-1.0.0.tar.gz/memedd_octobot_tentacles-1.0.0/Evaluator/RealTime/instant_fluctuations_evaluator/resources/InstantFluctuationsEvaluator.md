Triggers when a superior to 1% change of price or a superior to x4 change of volume from recent average happens.

The price distance from recent average is defining the strength the evaluation.