Uses the [Relative Strength Index](https://www.investopedia.com/terms/r/rsi.asp) to find trend reversals. 

When found, evaluates -1 to 1 according to the strength of the [RSI](https://www.investopedia.com/terms/r/rsi.asp).