from .blank_strategy import BlankStrategyEvaluator
