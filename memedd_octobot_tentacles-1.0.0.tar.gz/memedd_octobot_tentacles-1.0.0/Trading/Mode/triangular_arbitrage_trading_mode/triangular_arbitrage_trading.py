#  Custom tentacle: TriangularArbitrageTradingMode — single-exchange 3-leg arbitrage

import dataclasses
import decimal
import typing

import octobot_commons.enums as commons_enums
import octobot_trading.api as trading_api
import octobot_trading.constants as trading_constants
import octobot_trading.enums as trading_enums
import octobot_trading.modes as trading_modes
import octobot_trading.personal_data as trading_personal_data
import octobot_trading.exchange_channel as exchanges_channel


Decimal = decimal.Decimal


@dataclasses.dataclass
class TriCycle:
    legs: list[str]  # [pair1, pair2, pair3]


class TriangularArbitrageTradingMode(trading_modes.AbstractTradingMode):
    CYCLES = "cycles"
    MIN_PROFIT_BPS = "min_profit_bps"
    ORDER_SIZE_USD = "order_size_usd"
    SLIPPAGE_PCT = "slippage_pct"

    def init_user_inputs(self, inputs: dict) -> None:
        self.UI.user_input(self.CYCLES, commons_enums.UserInputTypes.TEXT, "BTC/USDT,ETH/BTC,ETH/USDT", inputs,
                           title="Comma-separated 3 legs (e.g., BTC/USDT,ETH/BTC,ETH/USDT)")
        self.UI.user_input(self.MIN_PROFIT_BPS, commons_enums.UserInputTypes.FLOAT, 15, inputs,
                           min_val=0, max_val=10_000, title="Minimum profitability in bps (15 = 0.15%)")
        self.UI.user_input(self.ORDER_SIZE_USD, commons_enums.UserInputTypes.FLOAT, 150, inputs,
                           min_val=0.0, max_val=1_000_000.0, title="USD size per cycle")
        self.UI.user_input(self.SLIPPAGE_PCT, commons_enums.UserInputTypes.FLOAT, 0.10, inputs,
                           min_val=0.0, max_val=5.0, title="Per-leg slippage %")

    def get_mode_producer_classes(self) -> list:
        return [TriArbProducer]

    def get_mode_consumer_classes(self) -> list:
        return [TriArbConsumer]

    @classmethod
    def get_forced_updater_channels(cls) -> set[str]:
        return {trading_constants.TICKER_CHANNEL}


class TriArbProducer(trading_modes.AbstractTradingModeProducer):
    def __init__(self, channel, config, trading_mode, exchange_manager):
        super().__init__(channel, config, trading_mode, exchange_manager)
        self.min_bps = Decimal(str(self.trading_mode.trading_config[TriangularArbitrageTradingMode.MIN_PROFIT_BPS]))
        self.usd = Decimal(str(self.trading_mode.trading_config[TriangularArbitrageTradingMode.ORDER_SIZE_USD]))
        self.slip = Decimal(str(self.trading_mode.trading_config[TriangularArbitrageTradingMode.SLIPPAGE_PCT])) / 100
        cycles_str = self.trading_mode.trading_config[TriangularArbitrageTradingMode.CYCLES]
        legs = [s.strip() for s in cycles_str.split(',') if s.strip()]
        if len(legs) != 3:
            self.cycle = TriCycle(legs=[])
        else:
            self.cycle = TriCycle(legs=legs)

    async def set_final_eval(self, matrix_id: str, cryptocurrency: str, symbol: str, time_frame, trigger_source: str):
        pass

    async def _on_ticker(self, data):
        em = self.exchange_manager
        legs = self.cycle.legs
        if len(legs) != 3:
            return
        p1 = await trading_api.get_price(em, legs[0])
        p2 = await trading_api.get_price(em, legs[1])
        p3 = await trading_api.get_price(em, legs[2])
        if p1 is None or p2 is None or p3 is None:
            return
        p1, p2, p3 = Decimal(str(p1)), Decimal(str(p2)), Decimal(str(p3))
        # crude profitability estimate (assumes supplied legs match Q->A, A->B, B->Q path)
        gross = (Decimal("1") / p1) * p2 * p3
        bps = (gross - Decimal("1")) * Decimal("10000")
        if bps >= self.min_bps:
            qty_base1 = self.usd / p1
            data = {
                TriArbConsumer.LEGS_KEY: legs,
                TriArbConsumer.QTY1_KEY: qty_base1,
                TriArbConsumer.PRICES_KEY: [p1, p2, p3],
            }
            await self.submit_trading_evaluation(cryptocurrency=self.trading_mode.cryptocurrency,
                                                 symbol=self.trading_mode.symbol,
                                                 time_frame=None,
                                                 state=trading_enums.EvaluatorStates.NEUTRAL,
                                                 data=data)

    async def start(self):
        await super().start()


class TriArbConsumer(trading_modes.AbstractTradingModeConsumer):
    LEGS_KEY = "legs"
    QTY1_KEY = "qty1"
    PRICES_KEY = "prices"

    def __init__(self, trading_mode):
        super().__init__(trading_mode)
        cfg = trading_mode.trading_config
        self.slip = Decimal(str(cfg[TriangularArbitrageTradingMode.SLIPPAGE_PCT])) / 100
        self._em = trading_mode.exchange_manager
        self._leg1_id = None
        self._leg2_id = None
        self._active = False
        self._legs = []

    def on_reload_config(self):
        pass

    async def create_new_orders(self, symbol, final_note, state, **kwargs):
        if self._active:
            return []
        data = kwargs[self.CREATE_ORDER_DATA_PARAM]
        legs: list[str] = data[self.LEGS_KEY]
        qty1: Decimal = data[self.QTY1_KEY]
        p1, p2, p3 = data[self.PRICES_KEY]
        # We assume legs are ordered as [A/Q, B/A, B/Q]
        base1, quote1 = self._split(legs[0])
        base2, quote2 = self._split(legs[1])
        base3, quote3 = self._split(legs[2])
        # Validate cycle continuity
        if not (quote1 == quote3 and base2 == base3 and quote2 == base1):
            # invalid order for simple pathing; skip
            return []
        self._legs = legs
        self._active = True
        # Leg1: BUY base1 with quote1
        price1 = p1 * (Decimal("1") + self.slip)
        self._leg1_id = await self._submit_return_id(self._em, legs[0], qty1, price1, trading_enums.TraderOrderType.BUY_LIMIT)
        # Subscribe to order updates once
        await exchanges_channel.get_chan(trading_personal_data.OrdersChannel.get_name(), self._em.id).new_consumer(
            self._on_order_event,
            symbol=self.trading_mode.symbol
        )
        return []

    async def _on_order_event(self, order_event: dict):
        try:
            order_id = order_event[trading_enums.ExchangeConstantsOrderColumns.ID.value]
            status = order_event[trading_enums.ExchangeConstantsOrderColumns.STATUS.value]
            filled_qty = Decimal(str(order_event.get(trading_enums.ExchangeConstantsOrderColumns.FILLED.value, "0")))
            price = Decimal(str(order_event.get(trading_enums.ExchangeConstantsOrderColumns.PRICE.value, "0")))
        except Exception:
            return
        if not self._active:
            return
        # When leg1 filled, place leg2 using received base1 qty
        if self._leg1_id and order_id == self._leg1_id and status in (trading_enums.OrderStatus.FILLED.value, trading_enums.OrderStatus.CLOSED.value):
            qty2 = filled_qty  # received base1 ~ quantity bought
            # Leg2 direction: BUY base2 with quote2 (= base1)
            price2 = await trading_api.get_price(self._em, self._legs[1])
            if price2 is None:
                self._reset()
                return
            price2 = Decimal(str(price2)) * (Decimal("1") + self.slip)
            self._leg2_id = await self._submit_return_id(self._em, self._legs[1], qty2, price2, trading_enums.TraderOrderType.BUY_LIMIT)
            return
        # When leg2 filled, place leg3 to convert to quote
        if self._leg2_id and order_id == self._leg2_id and status in (trading_enums.OrderStatus.FILLED.value, trading_enums.OrderStatus.CLOSED.value):
            qty3 = Decimal(str(order_event.get(trading_enums.ExchangeConstantsOrderColumns.FILLED.value, "0")))
            price3 = await trading_api.get_price(self._em, self._legs[2])
            if price3 is None:
                self._reset()
                return
            price3 = Decimal(str(price3)) * (Decimal("1") - self.slip)
            await self._submit_return_id(self._em, self._legs[2], qty3, price3, trading_enums.TraderOrderType.SELL_LIMIT)
            self._reset()

    def _reset(self):
        self._active = False
        self._leg1_id = None
        self._leg2_id = None
        self._legs = []

    @staticmethod
    def _split(pair: str):
        if "/" in pair:
            b, q = pair.split("/")
        else:
            b, q = pair.split("-")
        return b, q

    async def _submit_return_id(self, em, symbol: str, qty: Decimal, price: Decimal, order_type: trading_enums.TraderOrderType):
        _, _, _, _, symbol_market = await trading_personal_data.get_pre_order_data(
            em, symbol=symbol, timeout=trading_constants.ORDER_DATA_FETCHING_TIMEOUT
        )
        price = trading_personal_data.decimal_adapt_price(symbol_market, price)
        qty = trading_personal_data.decimal_adapt_quantity(symbol_market, qty)
        order = trading_personal_data.create_order_instance(
            trader=em.trader,
            order_type=order_type,
            symbol=symbol,
            current_price=price,
            quantity=qty,
            price=price
        )
        created = await self.trading_mode.create_order(order)
        return created.order_id if created else None
