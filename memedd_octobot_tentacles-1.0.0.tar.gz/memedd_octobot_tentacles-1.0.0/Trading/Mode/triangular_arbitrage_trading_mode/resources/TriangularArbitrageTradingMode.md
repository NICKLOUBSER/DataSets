TriangularArbitrageTradingMode implements single-exchange triangular arbitrage by executing three sequential trades to profit from price inefficiencies.

## Overview

This trading mode identifies triangular arbitrage opportunities by:

1. **Monitoring Three-Leg Cycles**: Watches three trading pairs that form a complete cycle (e.g., BTC/USDT → ETH/BTC → ETH/USDT)
2. **Calculating Profitability**: Computes the theoretical profit from executing the full cycle
3. **Sequential Execution**: When profitability exceeds the threshold, executes trades sequentially:
   - **Leg 1**: Buy the first asset with the base currency
   - **Leg 2**: When Leg 1 fills, buy the second asset with the first asset
   - **Leg 3**: When Leg 2 fills, sell the second asset for the base currency

## Configuration

- **Cycles**: Comma-separated list of three trading pairs forming the arbitrage cycle (e.g., "BTC/USDT,ETH/BTC,ETH/USDT")
- **Min Profit BPS**: Minimum profitability in basis points to trigger execution (default: 15 bps = 0.15%)
- **Order Size USD**: USD notional size for the arbitrage cycle
- **Slippage %**: Slippage buffer applied to each leg of the trade

## Example Cycle

For the cycle "BTC/USDT,ETH/BTC,ETH/USDT":
1. Buy BTC with USDT
2. Buy ETH with BTC (received from step 1)
3. Sell ETH for USDT (received from step 2)

## Risk Considerations

- **Execution Risk**: Sequential nature means later legs depend on earlier fills
- **Market Risk**: Prices can move unfavorably between leg executions
- **Liquidity Risk**: Requires sufficient liquidity in all three pairs
- **Timing Risk**: Fast execution required to capture arbitrage opportunities

_This trading mode supports PNL history._
