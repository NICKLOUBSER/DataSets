#  Custom tentacle: SpotPerpBasisTradingMode — open/close spot–perp hedges on basis divergence

import dataclasses
import decimal
import typing

import octobot_commons.enums as commons_enums
import octobot_commons.pretty_printer as pretty_printer
import octobot_trading.api as trading_api
import octobot_trading.constants as trading_constants
import octobot_trading.enums as trading_enums
import octobot_trading.modes as trading_modes
import octobot_trading.personal_data as trading_personal_data
import octobot_trading.exchange_channel as exchanges_channel


Decimal = decimal.Decimal


@dataclasses.dataclass
class HedgePosition:
    side: str  # 'long_basis' (long perp short spot) or 'short_basis' (long spot short perp)
    qty: Decimal
    open_spot_price: Decimal
    open_perp_price: Decimal


class SpotPerpBasisTradingMode(trading_modes.AbstractTradingMode):
    SPOT_EXCHANGE = "spot_exchange"
    PERP_EXCHANGE = "perp_exchange"
    SPOT_SYMBOL = "spot_symbol"
    PERP_SYMBOL = "perp_symbol"
    OPEN_BASIS_PCT = "min_opening_arbitrage_pct"
    CLOSE_BASIS_PCT = "min_closing_arbitrage_pct"
    ORDER_SIZE_USD = "order_size_usd"
    SLIP_SPOT = "spot_slippage_pct"
    SLIP_PERP = "perp_slippage_pct"

    def init_user_inputs(self, inputs: dict) -> None:
        self.UI.user_input(self.SPOT_EXCHANGE, commons_enums.UserInputTypes.TEXT, "binance", inputs,
                           title="Spot exchange (e.g., binance)")
        self.UI.user_input(self.PERP_EXCHANGE, commons_enums.UserInputTypes.TEXT, "binance", inputs,
                           title="Perp exchange (e.g., binance)")
        self.UI.user_input(self.SPOT_SYMBOL, commons_enums.UserInputTypes.TEXT, "BTC/USDT", inputs,
                           title="Spot symbol (e.g., BTC/USDT)")
        self.UI.user_input(self.PERP_SYMBOL, commons_enums.UserInputTypes.TEXT, "BTC/USDT", inputs,
                           title="Perp symbol (e.g., BTC/USDT)")
        self.UI.user_input(self.OPEN_BASIS_PCT, commons_enums.UserInputTypes.FLOAT, 0.30, inputs,
                           min_val=-100, max_val=100,
                           title="Open hedge when |basis| >= this % (0.30 = 0.30%)")
        self.UI.user_input(self.CLOSE_BASIS_PCT, commons_enums.UserInputTypes.FLOAT, 0.05, inputs,
                           min_val=-100, max_val=100,
                           title="Close hedge when |basis| <= this % (0.05 = 0.05%)")
        self.UI.user_input(self.ORDER_SIZE_USD, commons_enums.UserInputTypes.FLOAT, 1000, inputs,
                           min_val=0.0, max_val=1_000_000,
                           title="USD notional per leg")
        self.UI.user_input(self.SLIP_SPOT, commons_enums.UserInputTypes.FLOAT, 0.05, inputs,
                           min_val=0.0, max_val=5.0,
                           title="Spot slippage buffer in %")
        self.UI.user_input(self.SLIP_PERP, commons_enums.UserInputTypes.FLOAT, 0.05, inputs,
                           min_val=0.0, max_val=5.0,
                           title="Perp slippage buffer in %")

    def get_mode_producer_classes(self) -> list:
        return [SpotPerpBasisProducer]

    def get_mode_consumer_classes(self) -> list:
        return [SpotPerpBasisConsumer]

    @classmethod
    def get_forced_updater_channels(cls) -> set[str]:
        return {trading_constants.TICKER_CHANNEL}


class SpotPerpBasisProducer(trading_modes.AbstractTradingModeProducer):
    def __init__(self, channel, config, trading_mode, exchange_manager):
        super().__init__(channel, config, trading_mode, exchange_manager)
        self.state = trading_enums.EvaluatorStates.NEUTRAL
        self.position: typing.Optional[HedgePosition] = None

        self.spot_ex = self.trading_mode.trading_config[SpotPerpBasisTradingMode.SPOT_EXCHANGE]
        self.perp_ex = self.trading_mode.trading_config[SpotPerpBasisTradingMode.PERP_EXCHANGE]
        self.spot_sym = self.trading_mode.trading_config[SpotPerpBasisTradingMode.SPOT_SYMBOL]
        self.perp_sym = self.trading_mode.trading_config[SpotPerpBasisTradingMode.PERP_SYMBOL]
        self.open_thr = Decimal(str(self.trading_mode.trading_config[SpotPerpBasisTradingMode.OPEN_BASIS_PCT])) / 100
        self.close_thr = Decimal(str(self.trading_mode.trading_config[SpotPerpBasisTradingMode.CLOSE_BASIS_PCT])) / 100
        self.order_usd = Decimal(str(self.trading_mode.trading_config[SpotPerpBasisTradingMode.ORDER_SIZE_USD]))
        self.slip_spot = Decimal(str(self.trading_mode.trading_config[SpotPerpBasisTradingMode.SLIP_SPOT])) / 100
        self.slip_perp = Decimal(str(self.trading_mode.trading_config[SpotPerpBasisTradingMode.SLIP_PERP])) / 100

    async def set_final_eval(self, matrix_id: str, cryptocurrency: str, symbol: str, time_frame, trigger_source: str):
        pass

    async def _on_ticker(self, data):
        # drive logic from any exchange manager; compute basis
        spot_em = trading_api.get_exchange_manager_by_name(self.spot_ex)
        perp_em = trading_api.get_exchange_manager_by_name(self.perp_ex)
        if spot_em is None or perp_em is None:
            return
        spot_mid = await trading_api.get_price(spot_em, self.spot_sym)
        perp_mid = await trading_api.get_price(perp_em, self.perp_sym)
        if spot_mid is None or perp_mid is None:
            return
        spot_mid = Decimal(str(spot_mid))
        perp_mid = Decimal(str(perp_mid))
        basis = (perp_mid - spot_mid) / spot_mid

        # No position: open on divergence
        if self.position is None:
            if basis >= self.open_thr:
                await self._open_position("long_basis", spot_em, perp_em, spot_mid, perp_mid)
            elif basis <= -self.open_thr:
                await self._open_position("short_basis", spot_em, perp_em, spot_mid, perp_mid)
        else:
            # Position open: close on convergence
            if abs(basis) <= self.close_thr:
                await self._close_position(spot_em, perp_em, spot_mid, perp_mid)

    async def _open_position(self, side: str, spot_em, perp_em, spot_mid: Decimal, perp_mid: Decimal):
        qty = await self._estimate_qty_from_usd(spot_em, self.spot_sym, self.order_usd, spot_mid)
        data = {
            SpotPerpBasisConsumer.ACTION_KEY: "open",
            SpotPerpBasisConsumer.SIDE_KEY: side,
            SpotPerpBasisConsumer.QTY_KEY: qty,
            SpotPerpBasisConsumer.SPOT_PRICE_KEY: spot_mid,
            SpotPerpBasisConsumer.PERP_PRICE_KEY: perp_mid,
        }
        await self.submit_trading_evaluation(cryptocurrency=self.trading_mode.cryptocurrency,
                                             symbol=self.trading_mode.symbol,
                                             time_frame=None,
                                             state=trading_enums.EvaluatorStates.NEUTRAL,
                                             data=data)

    async def _close_position(self, spot_em, perp_em, spot_mid, perp_mid):
        pos = self.position
        if pos is None:
            return
        data = {
            SpotPerpBasisConsumer.ACTION_KEY: "close",
            SpotPerpBasisConsumer.SIDE_KEY: pos.side,
            SpotPerpBasisConsumer.QTY_KEY: pos.qty,
            SpotPerpBasisConsumer.SPOT_PRICE_KEY: spot_mid,
            SpotPerpBasisConsumer.PERP_PRICE_KEY: perp_mid,
        }
        await self.submit_trading_evaluation(cryptocurrency=self.trading_mode.cryptocurrency,
                                             symbol=self.trading_mode.symbol,
                                             time_frame=None,
                                             state=trading_enums.EvaluatorStates.NEUTRAL,
                                             data=data)

    @staticmethod
    async def _estimate_qty_from_usd(exchange_manager, symbol: str, usd: Decimal, price: Decimal) -> Decimal:
        _, _, _, _, symbol_market = await trading_personal_data.get_pre_order_data(
            exchange_manager, symbol=symbol, timeout=trading_constants.ORDER_DATA_FETCHING_TIMEOUT
        )
        raw = usd / price
        return trading_personal_data.decimal_adapt_quantity(symbol_market, raw)

    async def start(self):
        # subscribe to any ticker (current exchange emits updates; we recompute basis from real exchanges inside)
        await super().start()


class SpotPerpBasisConsumer(trading_modes.AbstractTradingModeConsumer):
    ACTION_KEY = "action"
    SIDE_KEY = "side"
    QTY_KEY = "qty"
    SPOT_PRICE_KEY = "spot_price"
    PERP_PRICE_KEY = "perp_price"

    def __init__(self, trading_mode: SpotPerpBasisTradingMode):
        super().__init__(trading_mode)
        cfg = trading_mode.trading_config
        self.spot_ex = cfg[SpotPerpBasisTradingMode.SPOT_EXCHANGE]
        self.perp_ex = cfg[SpotPerpBasisTradingMode.PERP_EXCHANGE]
        self.spot_sym = cfg[SpotPerpBasisTradingMode.SPOT_SYMBOL]
        self.perp_sym = cfg[SpotPerpBasisTradingMode.PERP_SYMBOL]
        self.slip_spot = Decimal(str(cfg[SpotPerpBasisTradingMode.SLIP_SPOT])) / 100
        self.slip_perp = Decimal(str(cfg[SpotPerpBasisTradingMode.SLIP_PERP])) / 100

        self._position: typing.Optional[HedgePosition] = None

    def on_reload_config(self):
        pass

    async def create_new_orders(self, symbol, final_note, state, **kwargs):
        data = kwargs[self.CREATE_ORDER_DATA_PARAM]
        action = data[self.ACTION_KEY]
        side = data[self.SIDE_KEY]
        qty: Decimal = data[self.QTY_KEY]
        spot_price: Decimal = data[self.SPOT_PRICE_KEY]
        perp_price: Decimal = data[self.PERP_PRICE_KEY]

        spot_em = trading_api.get_exchange_manager_by_name(self.spot_ex)
        perp_em = trading_api.get_exchange_manager_by_name(self.perp_ex)
        if spot_em is None or perp_em is None:
            return []

        orders = []
        if action == "open" and self._position is None:
            if side == "long_basis":
                # long perp, short spot
                orders += await self._submit_limit(perp_em, self.perp_sym, qty, perp_price * (Decimal("1") + self.slip_perp), trading_enums.TraderOrderType.BUY_LIMIT)
                orders += await self._submit_limit(spot_em, self.spot_sym, qty, spot_price * (Decimal("1") - self.slip_spot), trading_enums.TraderOrderType.SELL_LIMIT)
            else:
                # short perp, long spot
                orders += await self._submit_limit(spot_em, self.spot_sym, qty, spot_price * (Decimal("1") + self.slip_spot), trading_enums.TraderOrderType.BUY_LIMIT)
                orders += await self._submit_limit(perp_em, self.perp_sym, qty, perp_price * (Decimal("1") - self.slip_perp), trading_enums.TraderOrderType.SELL_LIMIT)
            self._position = HedgePosition(side=side, qty=qty, open_spot_price=spot_price, open_perp_price=perp_price)

        elif action == "close" and self._position is not None:
            if self._position.side == "long_basis":
                # close: sell perp bought, buy back spot sold
                orders += await self._submit_limit(perp_em, self.perp_sym, self._position.qty, perp_price * (Decimal("1") - self.slip_perp), trading_enums.TraderOrderType.SELL_LIMIT)
                orders += await self._submit_limit(spot_em, self.spot_sym, self._position.qty, spot_price * (Decimal("1") + self.slip_spot), trading_enums.TraderOrderType.BUY_LIMIT)
            else:
                # close: buy perp sold, sell spot bought
                orders += await self._submit_limit(perp_em, self.perp_sym, self._position.qty, perp_price * (Decimal("1") + self.slip_perp), trading_enums.TraderOrderType.BUY_LIMIT)
                orders += await self._submit_limit(spot_em, self.spot_sym, self._position.qty, spot_price * (Decimal("1") - self.slip_spot), trading_enums.TraderOrderType.SELL_LIMIT)
            self._position = None

        return orders

    async def _submit_limit(self, em, symbol: str, qty: Decimal, price: Decimal, order_type: trading_enums.TraderOrderType):
        _, _, _, _, symbol_market = await trading_personal_data.get_pre_order_data(
            em, symbol=symbol, timeout=trading_constants.ORDER_DATA_FETCHING_TIMEOUT
        )
        price = trading_personal_data.decimal_adapt_price(symbol_market, price)
        qty = trading_personal_data.decimal_adapt_quantity(symbol_market, qty)
        order = trading_personal_data.create_order_instance(
            trader=em.trader,
            order_type=order_type,
            symbol=symbol,
            current_price=price,
            quantity=qty,
            price=price
        )
        created = await self.trading_mode.create_order(order)
        return [created] if created else []
