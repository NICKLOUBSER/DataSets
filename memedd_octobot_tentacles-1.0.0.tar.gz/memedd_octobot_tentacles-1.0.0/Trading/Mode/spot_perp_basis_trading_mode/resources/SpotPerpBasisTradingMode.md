SpotPerpBasisTradingMode implements spot-perpetual basis trading by monitoring price differences between spot and perpetual futures markets.

## Overview

This trading mode identifies arbitrage opportunities between spot and perpetual futures markets by:

1. **Monitoring Basis**: Continuously calculates the basis (price difference) between spot and perpetual futures prices
2. **Opening Hedges**: When the basis exceeds the configured threshold, opens a hedge position:
   - **Long Basis**: Long perpetual, short spot (when perp > spot)
   - **Short Basis**: Long spot, short perpetual (when spot > perp)
3. **Closing Hedges**: Closes positions when the basis converges below the closing threshold

## Configuration

- **Spot Exchange**: The exchange for spot trading (e.g., binance)
- **Perp Exchange**: The exchange for perpetual futures trading (e.g., binance)
- **Spot Symbol**: Trading pair for spot market (e.g., BTC/USDT)
- **Perp Symbol**: Trading pair for perpetual market (e.g., BTC/USDT)
- **Min Opening Arbitrage %**: Minimum basis percentage to open a hedge (default: 0.30%)
- **Min Closing Arbitrage %**: Maximum basis percentage to close a hedge (default: 0.05%)
- **Order Size USD**: USD notional size per leg of the hedge
- **Spot Slippage %**: Slippage buffer for spot orders
- **Perp Slippage %**: Slippage buffer for perpetual orders

## Risk Considerations

- Requires accounts on both spot and perpetual exchanges
- Market risk from basis convergence timing
- Execution risk from slippage and order fills
- Requires sufficient balance on both exchanges

_This trading mode supports PNL history._
