#  Custom tentacle: XemmHedgerTradingMode (passive maker + taker hedge)
#  Minimal initial implementation for OctoBot 2.0.12 — paper trading oriented.

import dataclasses
import decimal
import typing

import octobot_commons.enums as commons_enums
import octobot_commons.pretty_printer as pretty_printer
import octobot_trading.api as trading_api
import octobot_trading.constants as trading_constants
import octobot_trading.enums as trading_enums
import octobot_trading.modes as trading_modes
import octobot_trading.personal_data as trading_personal_data
import octobot_trading.exchange_channel as exchanges_channel


Decimal = decimal.Decimal


@dataclasses.dataclass
class HedgePlan:
    side: trading_enums.TradeOrderSide
    entry_price: Decimal
    taker_price_limit: Decimal
    qty: Decimal
    maker_exchange: str
    taker_exchange: str
    symbol: str


class XemmHedgerTradingMode(trading_modes.AbstractTradingMode):
    """
    Places a passive limit on maker exchange when cross-venue spread >= min_profitability_pct.
    On fill, submits a market/limit hedge on taker exchange with slippage buffer.

    Notes:
    - This initial version focuses on paper/simulator and keeps a single open hedge at a time.
    - It expects both exchanges enabled in the profile and the same symbol on each.
    """

    MIN_PROFITABILITY = "min_profitability_pct"
    SLIPPAGE = "slippage_pct"
    ORDER_SIZE_USD = "order_size_usd"
    MAKER_EXCHANGE = "maker_exchange"
    TAKER_EXCHANGE = "taker_exchange"
    ANTI_HYSTERESIS_SEC = "anti_hysteresis_sec"

    def init_user_inputs(self, inputs: dict) -> None:
        self.UI.user_input(self.MAKER_EXCHANGE, commons_enums.UserInputTypes.TEXT, "okx", inputs,
                           title="Maker exchange name (e.g., binance, okx)")
        self.UI.user_input(self.TAKER_EXCHANGE, commons_enums.UserInputTypes.TEXT, "binance", inputs,
                           title="Taker exchange name (e.g., binance, okx)")
        self.UI.user_input(self.MIN_PROFITABILITY, commons_enums.UserInputTypes.FLOAT, 0.35, inputs,
                           min_val=0.0, max_val=100.0,
                           title="Minimum cross-venue profitability in % (Enter 0.35 for 0.35%)")
        self.UI.user_input(self.SLIPPAGE, commons_enums.UserInputTypes.FLOAT, 0.08, inputs,
                           min_val=0.0, max_val=5.0,
                           title="Hedge slippage buffer in % (Enter 0.08 for 0.08%)")
        self.UI.user_input(self.ORDER_SIZE_USD, commons_enums.UserInputTypes.FLOAT, 150, inputs,
                           min_val=0.0, max_val=1_000_000.0, title="Target USD notional per leg")
        self.UI.user_input(self.ANTI_HYSTERESIS_SEC, commons_enums.UserInputTypes.FLOAT, 10, inputs,
                           min_val=0.0, max_val=600.0, title="Min seconds between quote refreshes")

    def get_mode_producer_classes(self) -> list:
        return [XemmHedgerProducer]

    def get_mode_consumer_classes(self) -> list:
        return [XemmHedgerConsumer]

    @classmethod
    def get_forced_updater_channels(cls) -> set[str]:
        return {trading_constants.TICKER_CHANNEL, trading_constants.ORDER_BOOK_CHANNEL}


class XemmHedgerProducer(trading_modes.AbstractTradingModeProducer):
    def __init__(self, channel, config, trading_mode, exchange_manager):
        super().__init__(channel, config, trading_mode, exchange_manager)
        self.state = trading_enums.EvaluatorStates.NEUTRAL
        self._last_action_ts = 0.0

        self._maker = self.trading_mode.trading_config[XemmHedgerTradingMode.MAKER_EXCHANGE]
        self._taker = self.trading_mode.trading_config[XemmHedgerTradingMode.TAKER_EXCHANGE]
        self._min_profit = Decimal(str(self.trading_mode.trading_config[XemmHedgerTradingMode.MIN_PROFITABILITY])) / 100
        self._slip = Decimal(str(self.trading_mode.trading_config[XemmHedgerTradingMode.SLIPPAGE])) / 100
        self._order_usd = Decimal(str(self.trading_mode.trading_config[XemmHedgerTradingMode.ORDER_SIZE_USD]))
        self._anti_hys = float(self.trading_mode.trading_config[XemmHedgerTradingMode.ANTI_HYSTERESIS_SEC])

    async def set_final_eval(self, matrix_id: str, cryptocurrency: str, symbol: str, time_frame, trigger_source: str):
        # Not used by this mode
        pass

    async def _on_order_book(self, data):
        # Placeholder for future depth-based sizing
        pass

    async def _on_ticker(self, data):
        # Called for current exchange; we only act when current exchange matches maker
        if trading_api.get_exchange_name(self.exchange_manager) != self._maker:
            return

        now = trading_api.get_exchange_current_time_seconds(self.exchange_manager)
        if now - self._last_action_ts < self._anti_hys:
            return

        symbol = self.trading_mode.symbol
        maker_mid = await trading_api.get_price(self.exchange_manager, symbol)
        if maker_mid is None:
            return

        taker_em = trading_api.get_exchange_manager_by_name(self._taker)
        if taker_em is None:
            return
        taker_mid = await trading_api.get_price(taker_em, symbol)
        if taker_mid is None:
            return

        maker_mid = Decimal(str(maker_mid))
        taker_mid = Decimal(str(taker_mid))

        # Evaluate both directions (sell maker / buy taker) and (buy maker / sell taker)
        sell_maker_edge = (taker_mid - maker_mid) / maker_mid
        buy_maker_edge = (maker_mid - taker_mid) / maker_mid

        if sell_maker_edge >= self._min_profit:
            await self._submit_plan(symbol, trading_enums.TradeOrderSide.SELL, maker_mid, taker_mid)
            self._last_action_ts = now
        elif buy_maker_edge >= self._min_profit:
            await self._submit_plan(symbol, trading_enums.TradeOrderSide.BUY, maker_mid, taker_mid)
            self._last_action_ts = now

    async def _submit_plan(self, symbol: str, maker_side: trading_enums.TradeOrderSide,
                           maker_mid: Decimal, taker_mid: Decimal):
        qty = await self._estimate_qty_from_usd(self.exchange_manager, symbol, self._order_usd, maker_mid)
        taker_price_limit = taker_mid * (Decimal("1") + (self._slip if maker_side is trading_enums.TradeOrderSide.BUY else -self._slip))
        plan = HedgePlan(side=maker_side, entry_price=maker_mid, taker_price_limit=taker_price_limit,
                         qty=qty, maker_exchange=self._maker, taker_exchange=self._taker, symbol=symbol)
        await self.submit_trading_evaluation(cryptocurrency=self.trading_mode.cryptocurrency,
                                             symbol=symbol,
                                             time_frame=None,
                                             state=trading_enums.EvaluatorStates.LONG if maker_side is trading_enums.TradeOrderSide.SELL else trading_enums.EvaluatorStates.SHORT,
                                             data={"hedge_plan": plan})

    @staticmethod
    async def _estimate_qty_from_usd(exchange_manager, symbol: str, usd: Decimal, price: Decimal) -> Decimal:
        _, _, market_qty, _, symbol_market = await trading_personal_data.get_pre_order_data(
            exchange_manager, symbol=symbol, timeout=trading_constants.ORDER_DATA_FETCHING_TIMEOUT
        )
        raw = usd / price
        return trading_personal_data.decimal_adapt_quantity(symbol_market, raw)

    async def start(self):
        # Subscribe to ticker updates
        await exchanges_channel.get_chan(trading_constants.TICKER_CHANNEL, self.exchange_manager.id).new_consumer(
            self._on_ticker,
            symbol=self.trading_mode.symbol
        )
        await super().start()


class XemmHedgerConsumer(trading_modes.AbstractTradingModeConsumer):
    HEDGE_PLAN_KEY = "hedge_plan"

    def __init__(self, trading_mode):
        super().__init__(trading_mode)
        self._open_order_id = None

    def on_reload_config(self):
        pass

    async def create_new_orders(self, symbol, final_note, state, **kwargs):
        plan: HedgePlan = kwargs[self.CREATE_ORDER_DATA_PARAM][self.HEDGE_PLAN_KEY]
        # Place passive on maker
        if self._open_order_id is not None:
            return []
        maker_em = trading_api.get_exchange_manager_by_name(plan.maker_exchange)
        if maker_em is None:
            return []
        # Build maker limit
        order_type = trading_enums.TraderOrderType.SELL_LIMIT if plan.side is trading_enums.TradeOrderSide.SELL \
            else trading_enums.TraderOrderType.BUY_LIMIT
        current_order = trading_personal_data.create_order_instance(
            trader=maker_em.trader,
            order_type=order_type,
            symbol=plan.symbol,
            current_price=plan.entry_price,
            quantity=plan.qty,
            price=plan.entry_price
        )
        created = await self.trading_mode.create_order(current_order)
        if created is None:
            return []
        self._open_order_id = created.order_id
        # Watch fills
        await exchanges_channel.get_chan(trading_personal_data.OrdersChannel.get_name(), maker_em.id).new_consumer(
            lambda data: self._on_order_event(plan, data), symbol=plan.symbol
        )
        return [created]

    async def _on_order_event(self, plan: HedgePlan, order_event: dict):
        try:
            order_id = order_event[trading_enums.ExchangeConstantsOrderColumns.ID.value]
            is_filled = order_event[trading_enums.ExchangeConstantsOrderColumns.STATUS.value] in (
                trading_enums.OrderStatus.FILLED.value, trading_enums.OrderStatus.CLOSED.value
            )
            if self._open_order_id and order_id == self._open_order_id and is_filled:
                await self._place_taker_hedge(plan, order_event)
                self._open_order_id = None
        except Exception:
            # ignore malformed updates
            pass

    async def _place_taker_hedge(self, plan: HedgePlan, filled_order: dict):
        taker_em = trading_api.get_exchange_manager_by_name(plan.taker_exchange)
        if taker_em is None:
            return
        qty = Decimal(str(filled_order.get(trading_enums.ExchangeConstantsOrderColumns.FILLED.value, plan.qty)))
        # Submit market with price guard as limit if available
        order_type = trading_enums.TraderOrderType.BUY_LIMIT if plan.side is trading_enums.TradeOrderSide.SELL \
            else trading_enums.TraderOrderType.SELL_LIMIT
        hedge_order = trading_personal_data.create_order_instance(
            trader=taker_em.trader,
            order_type=order_type,
            symbol=plan.symbol,
            current_price=plan.taker_price_limit,
            quantity=qty,
            price=plan.taker_price_limit
        )
        await self.trading_mode.create_order(hedge_order)
