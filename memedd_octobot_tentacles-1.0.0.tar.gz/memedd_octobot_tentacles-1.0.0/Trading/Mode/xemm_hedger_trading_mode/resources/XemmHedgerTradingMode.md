XemmHedgerTradingMode implements cross-exchange market making (XEMM) by placing passive orders on one exchange and hedging fills on another exchange.

## Overview

This trading mode implements a cross-exchange market making strategy by:

1. **Monitoring Cross-Exchange Spreads**: Continuously compares prices between two exchanges
2. **Placing Passive Orders**: When the spread exceeds the minimum profitability threshold, places a passive limit order on the maker exchange
3. **Hedging Fills**: When the passive order fills, immediately places a hedge order on the taker exchange to lock in profit

## Strategy Details

- **Maker Exchange**: Exchange where passive limit orders are placed (typically with better maker fees)
- **Taker Exchange**: Exchange used for hedging fills (typically with better taker fees or liquidity)
- **Profit Capture**: Captures the spread between exchanges minus slippage and fees
- **Risk Management**: Only maintains one open position at a time to limit exposure

## Configuration

- **Maker Exchange**: Exchange name for placing passive orders (e.g., okx, binance)
- **Taker Exchange**: Exchange name for hedging fills (e.g., binance, okx)
- **Min Profitability %**: Minimum spread percentage to trigger order placement (default: 0.35%)
- **Slippage %**: Slippage buffer applied to hedge orders (default: 0.08%)
- **Order Size USD**: Target USD notional size per trade
- **Anti Hysteresis Sec**: Minimum seconds between quote refreshes to prevent excessive trading

## Risk Considerations

- **Cross-Exchange Risk**: Requires accounts and balances on both exchanges
- **Execution Risk**: Hedge orders may not fill at expected prices
- **Latency Risk**: Price movements between order placement and hedge execution
- **Liquidity Risk**: Requires sufficient liquidity on both exchanges
- **Regulatory Risk**: Cross-exchange trading may have regulatory implications

## Example Scenario

1. OKX BTC/USDT: $50,000 (maker exchange)
2. Binance BTC/USDT: $50,200 (taker exchange)
3. Spread: 0.40% > 0.35% threshold
4. Place sell limit at $50,000 on OKX
5. When filled, buy at $50,200 + slippage on Binance
6. Profit: ~0.40% minus fees and slippage

_This trading mode supports PNL history._
