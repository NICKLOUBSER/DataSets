#!/usr/bin/env python3

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read version from metadata.yaml
version = "1.0.0"
with open(os.path.join(this_directory, 'metadata.yaml'), 'r') as f:
    for line in f:
        if line.startswith('version:'):
            version = line.split(':', 1)[1].strip()
            break

setup(
    name="memedd-octobot-tentacles",
    version=version,
    author="MemeDD",
    author_email="contact@memedd.com",
    description="Custom trading modes and profiles for MemeDD strategies",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/MemeDD/OctoBot-Tentacles",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.8",
    install_requires=[
        "OctoBot-Commons>=1.9.82",
        "OctoBot-Trading>=2.4.217",
    ],
    include_package_data=True,
    package_data={
        "": ["*.json", "*.yaml", "*.md"],
    },
    zip_safe=False,
)
