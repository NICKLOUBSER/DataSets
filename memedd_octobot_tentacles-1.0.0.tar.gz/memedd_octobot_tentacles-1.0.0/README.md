# MemeDD pack V1 - OctoBot Tentacles

This repository contains custom trading modes and profiles for MemeDD strategies, designed for advanced trading scenarios including arbitrage and hedging strategies.

## Features

### Trading Modes
- **SpotPerp Basis Trading Mode**: Exploits price differences between spot and perpetual futures markets
- **Triangular Arbitrage Trading Mode**: Executes triangular arbitrage opportunities across multiple trading pairs
- **XEMM Hedger Trading Mode**: Cross-exchange market making with hedging capabilities

### Included Profiles
- `SpotPerp Basis_ Binance`: Optimized for Binance spot and futures markets
- `Triangular Arbitrage_ Binance (BTC, ETH, USDT)`: Triangular arbitrage strategy for BTC/ETH/USDT pairs
- `XEMM Hedger_ Binance OKX (PEPE_USDT)`: Cross-exchange hedging for PEPE/USDT across Binance and OKX

## Installation

### For Live OctoBot
1. Download this package as a ZIP file
2. In your OctoBot interface, go to Settings > Tentacles
3. Click "Import Tentacles Package" and select the ZIP file
4. Restart OctoBot

### For Development
```bash
# Clone the repository
git clone https://github.com/MemeDD/OctoBot-Tentacles.git

# Install in development mode
cd OctoBot-Tentacles
pip install -e .
```

## Usage

1. Import the package into your OctoBot instance
2. Select one of the included profiles or create a custom configuration
3. Configure your exchange API keys
4. Start trading with your chosen strategy

## Requirements

- OctoBot-Commons >= 1.9.82
- OctoBot-Trading >= 2.4.217
- Supported exchanges: Binance, OKX

## License

This project is licensed under the LGPL-3.0 License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions, please contact MemeDD team.