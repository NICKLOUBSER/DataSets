Uses the [Stochastic RSI](https://www.investopedia.com/terms/s/stochrsi.asp) as a volatilty evaluator to identify trends.

When found, evaluates from -1 to 1 according to the strength of the trend.