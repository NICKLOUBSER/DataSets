Uses the [Relative Strength Index](https://www.investopedia.com/terms/r/rsi.asp) to find dips and give them weight according to the trend
