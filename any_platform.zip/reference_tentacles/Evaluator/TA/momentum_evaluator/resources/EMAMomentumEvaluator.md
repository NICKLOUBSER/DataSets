Uses  [exponential moving averages](https://www.investopedia.com/terms/m/movingaverage.asp) to find signal when the current price exceeds the average value.

Evaluates -1 or 1 when the current price is far enough from the EMA.