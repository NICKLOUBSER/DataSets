Evaluator that catch Telegram channel signals.

Triggers on a Telegram signal from any channel your personal account joined.

Signal parsing is configurable according to the name of the channel.

See [OctoBot docs about Telegram API service](https://www.octobot.cloud/en/guides/octobot-interfaces/telegram/telegram-api?utm_source=octobot&utm_medium=dk&utm_campaign=regular_open_source_content&utm_content=telegramChannelSignalEvaluator) for more information.
