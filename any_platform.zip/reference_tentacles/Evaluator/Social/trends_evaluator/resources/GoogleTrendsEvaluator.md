Analyses the popularity of the given currencies using their names. 

Data are provided by [Google's trends service](https://trends.google.com/trends/?geo=US).
 
Due to Google trends poor refresh rate, this evaluation should be considered for large time frames only.