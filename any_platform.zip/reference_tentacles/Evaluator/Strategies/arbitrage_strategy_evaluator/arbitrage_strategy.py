# Custom Arbitrage Strategy Evaluator for OctoBot Trading Modes

import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_commons.enums as commons_enums


class ArbitrageStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Custom strategy evaluator for arbitrage trading modes.
    Provides signals for spot-perp basis trading, triangular arbitrage, and XEMM hedging.
    """
    
    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        # Enable the evaluator
        self.enabled = True
        # Set eval_note between -1 and 1
        self.eval_note = 0
        # For threaded evaluators (not strategies)
        self.is_threaded = True
        
    @classmethod
    def get_name(cls) -> str:
        return "ArbitrageStrategyEvaluator"
    
    @classmethod
    def get_evaluator_type(cls):
        return evaluators_enums.EvaluatorMatrixTypes.STRATEGIES
    
    @classmethod
    def get_default_time_frames(cls) -> list:
        return ["1m"]
    
    @classmethod
    def get_required_candles_count(cls) -> int:
        return 1  # Only need current price data
    
    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Matrix callback for arbitrage strategy evaluator.
        This evaluator provides NEUTRAL signals by default, allowing trading modes
        to handle their own arbitrage logic based on real-time price data.
        """
        try:
            # Set neutral state - trading modes will handle specific arbitrage logic
            self.eval_note = commons_enums.EvaluatorStates.NEUTRAL
            
            # Log that evaluator is running (for debugging)
            self.logger.debug(f"ArbitrageStrategyEvaluator running for {symbol} on {exchange_name}")
            
            # Complete the strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                
        except Exception as e:
            self.logger.error(f"Error in ArbitrageStrategyEvaluator matrix_callback: {e}")
            self.eval_note = commons_enums.EvaluatorStates.NEUTRAL
