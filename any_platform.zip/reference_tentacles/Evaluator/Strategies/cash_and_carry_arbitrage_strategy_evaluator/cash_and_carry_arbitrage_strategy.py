# Cash-and-Carry Arbitrage Strategy Evaluator for OctoBot
# Implements cash-and-carry arbitrage by monitoring spot and futures price spreads

import numpy as np
import octobot_commons.constants as commons_constants
import octobot_commons.enums as commons_enums
import octobot_evaluators.evaluators as evaluators
import octobot_evaluators.enums as evaluators_enums
import octobot_evaluators.matrix as matrix
import octobot_trading.api as trading_api
from decimal import Decimal


class CashAndCarryArbitrageStrategyEvaluator(evaluators.StrategyEvaluator):
    """
    Cash-and-Carry Arbitrage Strategy Evaluator.
    
    This strategy:
    - Monitors spot and futures prices for the same underlying asset
    - Calculates the basis (futures_price - spot_price)
    - Calculates theoretical futures price including carrying costs
    - Generates buy/sell signals when actual futures price exceeds theoretical price
    - Identifies arbitrage opportunities where: futures_price > spot_price + carrying_costs
    """
    
    def __init__(self, tentacles_setup_config):
        super().__init__(tentacles_setup_config)
        self.enabled = True
        self.eval_note = commons_constants.START_PENDING_EVAL_NOTE
        self.is_threaded = True
        
        # Strategy parameters (will be set from user inputs)
        self.spotSymbol = "BTC/USDT"
        self.futuresSymbol = "BTC/USDT:USDT"
        self.riskFreeRate = 0.05  # Annual risk-free rate (5%)
        self.storageCostPct = 0.0  # Storage cost as percentage (0% for crypto)
        self.minArbitrageProfitPct = 0.1  # Minimum profit percentage to enter (0.1%)
        self.lookbackPeriod = 50  # Number of candles for moving average calculation
        
        # Data storage
        self.basisHistory = []  # Historical basis values
        self.spotPrices = []  # Historical spot prices
        self.futuresPrices = []  # Historical futures prices
        
    @classmethod
    def get_name(cls) -> str:
        return "CashAndCarryArbitrageStrategyEvaluator"
    
    @classmethod
    def get_evaluator_type(cls):
        return evaluators_enums.EvaluatorMatrixTypes.STRATEGIES
    
    @classmethod
    def get_default_time_frames(cls) -> list:
        return ["5m", "15m", "1h"]
    
    @classmethod
    def get_required_candles_count(cls) -> int:
        return 100  # Need enough history for basis analysis
    
    def init_user_inputs(self, inputs: dict) -> None:
        """
        Initialize user-configurable parameters.
        """
        super().init_user_inputs(inputs)
        
        # Safely access UI, fallback to inputs dict if UI is not available
        ui = getattr(self, 'UI', None)
        if ui is None:
            # Fallback: use values from inputs dict or keep defaults
            self.spotSymbol = inputs.get("spot_symbol", self.spotSymbol)
            self.futuresSymbol = inputs.get("futures_symbol", self.futuresSymbol)
            self.riskFreeRate = inputs.get("risk_free_rate", self.riskFreeRate)
            self.storageCostPct = inputs.get("storage_cost_pct", self.storageCostPct)
            self.minArbitrageProfitPct = inputs.get("min_arbitrage_profit_pct", self.minArbitrageProfitPct)
            self.lookbackPeriod = inputs.get("lookback_period", self.lookbackPeriod)
            return
        
        self.spotSymbol = ui.user_input(
            "spot_symbol",
            commons_enums.UserInputTypes.TEXT,
            "BTC/USDT",
            inputs,
            title="Spot Symbol: Spot trading pair (e.g., BTC/USDT)"
        )
        
        self.futuresSymbol = ui.user_input(
            "futures_symbol",
            commons_enums.UserInputTypes.TEXT,
            "BTC/USDT:USDT",
            inputs,
            title="Futures Symbol: Futures trading pair (e.g., BTC/USDT:USDT for linear futures)"
        )
        
        self.riskFreeRate = ui.user_input(
            "risk_free_rate",
            commons_enums.UserInputTypes.FLOAT,
            0.05,
            inputs,
            min_val=0.0,
            max_val=0.20,
            title="Risk-Free Rate: Annual risk-free interest rate (e.g., 0.05 = 5%)"
        )
        
        self.storageCostPct = ui.user_input(
            "storage_cost_pct",
            commons_enums.UserInputTypes.FLOAT,
            0.0,
            inputs,
            min_val=0.0,
            max_val=1.0,
            title="Storage Cost %: Annual storage cost as percentage (0% for crypto, higher for commodities)"
        )
        
        self.minArbitrageProfitPct = ui.user_input(
            "min_arbitrage_profit_pct",
            commons_enums.UserInputTypes.FLOAT,
            0.1,
            inputs,
            min_val=0.01,
            max_val=5.0,
            title="Min Arbitrage Profit %: Minimum profit percentage to enter trade (e.g., 0.1 = 0.1%)"
        )
        
        self.lookbackPeriod = ui.user_input(
            "lookback_period",
            commons_enums.UserInputTypes.INT,
            50,
            inputs,
            min_val=10,
            max_val=200,
            title="Lookback Period: Number of candles for moving average calculation"
        )
    
    def _calculate_theoretical_futures_price(self, spot_price: float, time_to_expiration_days: float = 30.0) -> float:
        """
        Calculate theoretical futures price using cost-of-carry model.
        
        Formula: F = S * (1 + r * t) + C
        Where:
        - F = Futures price
        - S = Spot price
        - r = Risk-free rate (annual)
        - t = Time to expiration (in years)
        - C = Carrying costs (storage, insurance, etc.)
        
        For crypto, we typically use:
        - Time to expiration: 30 days (default for perpetuals, adjust for dated futures)
        - Storage cost: 0% (crypto doesn't require physical storage)
        """
        if spot_price <= 0:
            return 0.0
        
        # Convert days to years
        time_years = time_to_expiration_days / 365.0
        
        # Calculate financing cost
        financing_cost = spot_price * self.riskFreeRate * time_years
        
        # Calculate storage cost
        storage_cost = spot_price * self.storageCostPct * time_years
        
        # Theoretical futures price
        theoretical_futures = spot_price + financing_cost + storage_cost
        
        return theoretical_futures
    
    def _calculate_basis(self, spot_price: float, futures_price: float) -> float:
        """
        Calculate basis (futures_price - spot_price).
        
        Positive basis: Futures trading at premium (contango)
        Negative basis: Futures trading at discount (backwardation)
        """
        if spot_price <= 0:
            return 0.0
        
        basis = futures_price - spot_price
        basis_pct = (basis / spot_price) * 100.0
        
        return basis_pct
    
    def _get_prices(self, exchange_manager, spot_symbol: str, futures_symbol: str, time_frame):
        """
        Get current spot and futures prices.
        """
        try:
            # Get spot price
            spot_data = trading_api.get_symbol_data(exchange_manager, spot_symbol, allow_creation=False)
            if spot_data is None:
                return None, None
            
            spot_candles = trading_api.get_symbol_historical_candles(
                spot_data, time_frame, limit=1
            )
            if spot_candles is None or len(spot_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value]) < 1:
                return None, None
            
            spot_price = spot_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value][-1]
            
            # Get futures price - try to find futures exchange manager
            # For now, assume same exchange manager (may need adjustment for cross-exchange)
            futures_data = trading_api.get_symbol_data(exchange_manager, futures_symbol, allow_creation=False)
            if futures_data is None:
                # Try alternative: use spot price as proxy if futures not available
                # In production, you'd want separate exchange managers for spot and futures
                return spot_price, None
            
            futures_candles = trading_api.get_symbol_historical_candles(
                futures_data, time_frame, limit=1
            )
            if futures_candles is None or len(futures_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value]) < 1:
                return spot_price, None
            
            futures_price = futures_candles[commons_enums.PriceIndexes.IND_PRICE_CLOSE.value][-1]
            
            return spot_price, futures_price
            
        except Exception as e:
            self.logger.error(f"Error getting prices for {spot_symbol}/{futures_symbol}: {e}")
            return None, None
    
    def _generate_signal(self, spot_price: float, futures_price: float, theoretical_futures: float) -> float:
        """
        Generate trading signal based on cash-and-carry arbitrage opportunity.
        
        Returns:
            - Positive value (0.0 to 1.0): Strong buy signal when futures > theoretical
            - Negative value (-1.0 to 0.0): Strong sell signal when futures < theoretical
            - 0.0: No arbitrage opportunity
        """
        if spot_price <= 0 or futures_price <= 0:
            return 0.0
        
        # Calculate actual profit opportunity
        actual_spread = futures_price - spot_price
        theoretical_spread = theoretical_futures - spot_price
        
        # Calculate profit percentage
        profit_pct = ((futures_price - theoretical_futures) / spot_price) * 100.0
        
        # Check if profit exceeds minimum threshold
        if profit_pct >= self.minArbitrageProfitPct:
            # Strong buy signal: Buy spot, sell futures
            # Normalize signal strength (0.0 to 1.0)
            signal_strength = min(profit_pct / (self.minArbitrageProfitPct * 2), 1.0)
            return signal_strength
        
        # Check if futures is significantly below theoretical (reverse cash-and-carry)
        elif profit_pct <= -self.minArbitrageProfitPct:
            # Strong sell signal: Sell spot, buy futures (reverse arbitrage)
            signal_strength = min(abs(profit_pct) / (self.minArbitrageProfitPct * 2), 1.0)
            return -signal_strength
        
        # No arbitrage opportunity
        return 0.0
    
    async def matrix_callback(self,
                              matrix_id,
                              evaluator_name,
                              evaluator_type,
                              eval_note,
                              eval_note_type,
                              exchange_name,
                              cryptocurrency,
                              symbol,
                              time_frame):
        """
        Main strategy evaluation callback.
        """
        try:
            # Get exchange manager
            exchange_id = trading_api.get_exchange_id_from_matrix_id(exchange_name, matrix_id)
            exchange_manager = trading_api.get_exchange_manager_from_exchange_id(exchange_id)
            
            if exchange_manager is None:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # Get current prices
            spot_price, futures_price = self._get_prices(
                exchange_manager, 
                self.spotSymbol, 
                self.futuresSymbol, 
                time_frame
            )
            
            if spot_price is None:
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # If futures price not available, use spot as proxy (for testing)
            if futures_price is None:
                # In production, you'd want to handle this differently
                # For now, assume no arbitrage if futures data unavailable
                self.eval_note = 0.0
                await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
                return
            
            # Calculate theoretical futures price
            # For perpetuals, use 30 days as default time to expiration
            # For dated futures, you'd calculate actual days to expiration
            time_to_expiration_days = 30.0  # Default for perpetuals
            theoretical_futures = self._calculate_theoretical_futures_price(
                spot_price, 
                time_to_expiration_days
            )
            
            # Calculate basis
            basis_pct = self._calculate_basis(spot_price, futures_price)
            
            # Store historical data
            self.basisHistory.append(basis_pct)
            self.spotPrices.append(spot_price)
            self.futuresPrices.append(futures_price)
            
            # Keep only recent history
            if len(self.basisHistory) > self.lookbackPeriod:
                self.basisHistory.pop(0)
                self.spotPrices.pop(0)
                self.futuresPrices.pop(0)
            
            # Generate signal
            signal = self._generate_signal(spot_price, futures_price, theoretical_futures)
            self.eval_note = signal
            
            # Log for debugging
            profit_pct = ((futures_price - theoretical_futures) / spot_price) * 100.0
            self.logger.debug(
                f"CashAndCarry: Spot={spot_price:.2f} | Futures={futures_price:.2f} | "
                f"Theoretical={theoretical_futures:.2f} | Basis={basis_pct:.3f}% | "
                f"Profit={profit_pct:.3f}% | Signal={signal:.3f}"
            )
            
            # Complete strategy evaluation
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)
            
        except Exception as e:
            self.logger.error(f"Error in CashAndCarryArbitrageStrategyEvaluator matrix_callback: {e}")
            self.eval_note = 0.0
            await self.strategy_completed(cryptocurrency, symbol, time_frame=time_frame)

