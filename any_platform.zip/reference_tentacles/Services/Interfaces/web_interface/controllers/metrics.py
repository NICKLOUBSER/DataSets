# Custom Metrics Page Controller for OctoBot Web Interface

import flask
import json
import time
import asyncio
from datetime import datetime

import octobot_services.interfaces.util as interfaces_util
import octobot_trading.api as trading_api
import octobot_trading.errors as trading_errors
import octobot_evaluators.api as evaluators_api
import octobot_commons.timestamp_util as timestamp_util
import tentacles.Services.Interfaces.web_interface.login as login
import tentacles.Services.Interfaces.web_interface.util as util
import tentacles.Services.Interfaces.web_interface.models.trading as trading_models


def register(blueprint):
    @blueprint.route("/metrics", methods=['GET'])
    @login.login_required_when_activated
    def metrics():
        """Custom metrics dashboard page"""
        try:
            # Get comprehensive metrics data
            metrics_data = get_comprehensive_metrics()
            return flask.render_template('metrics.html', metrics=metrics_data)
        except Exception as e:
            return util.get_rest_reply(f"Error loading metrics: {str(e)}", 500)

    @blueprint.route("/api/metrics", methods=['GET'])
    @login.login_required_when_activated
    def api_metrics():
        """API endpoint for metrics data in JSON format"""
        try:
            metrics_data = get_comprehensive_metrics()
            return flask.jsonify(metrics_data)
        except Exception as e:
            return flask.jsonify({"error": str(e)}), 500

    @blueprint.route("/api/metrics/prometheus", methods=['GET'])
    @login.login_required_when_activated
    def api_metrics_prometheus():
        """API endpoint for metrics data in Prometheus format for scraping"""
        try:
            metrics_data = get_comprehensive_metrics()
            
            # Convert to Prometheus format
            prometheus_lines = []
            
            # System metrics
            system = metrics_data.get("system", {})
            prometheus_lines.append(f"# HELP octobot_system_cpu_usage_percent CPU usage percentage")
            prometheus_lines.append(f"# TYPE octobot_system_cpu_usage_percent gauge")
            prometheus_lines.append(f"octobot_system_cpu_usage_percent {system.get('cpu_usage_percent', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_system_memory_usage_mb Memory usage in MB")
            prometheus_lines.append(f"# TYPE octobot_system_memory_usage_mb gauge")
            prometheus_lines.append(f"octobot_system_memory_usage_mb {system.get('memory_usage_mb', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_system_uptime_seconds System uptime in seconds")
            prometheus_lines.append(f"# TYPE octobot_system_uptime_seconds counter")
            prometheus_lines.append(f"octobot_system_uptime_seconds {system.get('uptime_seconds', 0)}")
            
            # Exchange metrics
            exchanges = metrics_data.get("exchanges", {})
            prometheus_lines.append(f"# HELP octobot_exchange_total Total number of exchanges")
            prometheus_lines.append(f"# TYPE octobot_exchange_total gauge")
            prometheus_lines.append(f"octobot_exchange_total {exchanges.get('total_exchanges', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_exchange_connected Number of connected exchanges")
            prometheus_lines.append(f"# TYPE octobot_exchange_connected gauge")
            prometheus_lines.append(f"octobot_exchange_connected {exchanges.get('connected_exchanges', 0)}")
            
            for exchange in exchanges.get("exchanges", []):
                exchange_name = exchange.get("name", "unknown")
                prometheus_lines.append(f"# HELP octobot_exchange_portfolio_value_usd Portfolio value in USD")
                prometheus_lines.append(f"# TYPE octobot_exchange_portfolio_value_usd gauge")
                prometheus_lines.append(f'octobot_exchange_portfolio_value_usd{{exchange="{exchange_name}"}} {exchange.get("portfolio_value_usd", 0)}')
            
            # Portfolio metrics
            portfolio = metrics_data.get("portfolio", {})
            prometheus_lines.append(f"# HELP octobot_portfolio_total_value_usd Total portfolio value in USD")
            prometheus_lines.append(f"# TYPE octobot_portfolio_total_value_usd gauge")
            prometheus_lines.append(f"octobot_portfolio_total_value_usd {portfolio.get('total_portfolio_value_usd', 0)}")
            
            # Trading metrics
            trading = metrics_data.get("trading", {})
            prometheus_lines.append(f"# HELP octobot_trading_open_orders Total number of open orders")
            prometheus_lines.append(f"# TYPE octobot_trading_open_orders gauge")
            prometheus_lines.append(f"octobot_trading_open_orders {trading.get('total_open_orders', 0)}")
            
            # Strategy metrics
            strategies = metrics_data.get("strategies", {})
            prometheus_lines.append(f"# HELP octobot_strategy_total Total number of strategies")
            prometheus_lines.append(f"# TYPE octobot_strategy_total gauge")
            prometheus_lines.append(f"octobot_strategy_total {strategies.get('total_strategies', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_strategy_enabled Number of enabled strategies")
            prometheus_lines.append(f"# TYPE octobot_strategy_enabled gauge")
            prometheus_lines.append(f"octobot_strategy_enabled {strategies.get('enabled_strategies', 0)}")
            
            for strategy in strategies.get("strategies", []):
                strategy_name = strategy.get("name", "unknown")
                prometheus_lines.append(f"# HELP octobot_strategy_eval_note Strategy evaluation note")
                prometheus_lines.append(f"# TYPE octobot_strategy_eval_note gauge")
                prometheus_lines.append(f'octobot_strategy_eval_note{{strategy="{strategy_name}"}} {strategy.get("eval_note", 0)}')
            
            # Return raw text format for Prometheus
            return '\n'.join(prometheus_lines) + '\n'
            
        except Exception as e:
            return f"octobot_error 1\n", 500


def get_comprehensive_metrics():
    """Get comprehensive metrics data from OctoBot"""
    try:
        # Get all metrics with fallback to empty dicts
        system_metrics = get_system_metrics() or {}
        exchange_metrics = get_exchange_metrics() or {}
        portfolio_metrics = get_portfolio_metrics() or {}
        trading_metrics = get_trading_metrics() or {}
        strategy_metrics = get_strategy_metrics() or {}
        performance_metrics = get_performance_metrics() or {}
        
        # Get detailed trading data
        orders_data = get_orders_data() or []
        trades_data = get_trades_data() or []
        positions_data = get_positions_data() or []
        profitability_data = get_profitability_data() or {}
        pnl_history_data = get_pnl_history_data() or []
        
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "system": system_metrics,
            "exchanges": exchange_metrics,
            "portfolio": portfolio_metrics,
            "trading": trading_metrics,
            "strategies": strategy_metrics,
            "performance": performance_metrics,
            "open_orders": orders_data,
            "trades": trades_data,
            "positions": positions_data,
            "profitability": profitability_data,
            "pnl_history": pnl_history_data
        }
        return metrics
    except Exception as e:
        return {
            "error": str(e), 
            "timestamp": datetime.now().isoformat(),
            "system": {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0},
            "exchanges": {"total_exchanges": 0, "connected_exchanges": 0, "exchanges": []},
            "portfolio": {"total_portfolio_value_usd": 0.0, "portfolio_by_exchange": {}, "portfolio_by_symbol": {}},
            "trading": {"total_open_orders": 0, "orders_by_exchange": {}, "orders_by_symbol": {}, "orders_by_side": {"buy": 0, "sell": 0}},
            "strategies": {"total_strategies": 0, "enabled_strategies": 0, "strategies": []},
            "performance": {"total_trades": 0, "total_volume_usd": 0.0, "total_fees_usd": 0.0, "pnl_usd": 0.0, "max_drawdown_percent": 0.0, "sharpe_ratio": 0.0, "volatility": 0.0},
            "open_orders": [],
            "trades": [],
            "positions": [],
            "profitability": {},
            "pnl_history": []
        }


def get_system_metrics():
    """Get system performance metrics"""
    try:
        import psutil
        process = psutil.Process()
        return {
            "cpu_usage_percent": process.cpu_percent(),
            "memory_usage_mb": process.memory_info().rss / 1024 / 1024,
            "uptime_seconds": time.time() - process.create_time()
        }
    except ImportError:
        return {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0}
    except Exception:
        return {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0}


def get_exchange_metrics():
    """Get exchange connection and status metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}
            
        exchanges = []
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                is_connected = trading_api.is_exchange_connected(exchange_manager)
                
                # Get portfolio value for this exchange
                portfolio_value = trading_api.get_portfolio_value(exchange_manager)
                
                exchanges.append({
                    "name": exchange_name,
                    "connected": is_connected,
                    "portfolio_value_usd": float(portfolio_value) if portfolio_value else 0.0,
                    "type": getattr(exchange_manager, 'exchange_type', 'unknown'),
                    "is_future": exchange_manager.is_future,
                    "is_simulated": trading_api.is_trader_simulated(exchange_manager)
                })
            except Exception as e:
                exchanges.append({
                    "name": str(exchange_manager),
                    "connected": False,
                    "portfolio_value_usd": 0.0,
                    "type": "unknown",
                    "error": str(e)
                })
        
        return {
            "total_exchanges": len(exchanges),
            "connected_exchanges": len([e for e in exchanges if e["connected"]]),
            "exchanges": exchanges
        }
    except Exception as e:
        return {"error": str(e), "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}


def get_portfolio_metrics():
    """Get portfolio value and balance metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_portfolio_value_usd": 0.0}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_portfolio_value_usd": 0.0}
            
        total_portfolio_value = 0.0
        portfolio_by_exchange = {}
        portfolio_by_symbol = {}
        portfolio_holdings = {}
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                
                # Get total portfolio value
                portfolio_value = trading_api.get_portfolio_value(exchange_manager)
                if portfolio_value:
                    portfolio_float = float(portfolio_value)
                    total_portfolio_value += portfolio_float
                    portfolio_by_exchange[exchange_name] = portfolio_float
                
                # Get portfolio by symbol with detailed info
                portfolio = trading_api.get_portfolio(exchange_manager)
                if portfolio:
                    for symbol, balance in portfolio.items():
                        if balance and balance.total > 0:
                            if symbol not in portfolio_holdings:
                                portfolio_holdings[symbol] = {
                                    "total": 0,
                                    "available": 0,
                                    "locked": 0,
                                    "exchanges": {}
                                }
                            
                            total_amount = float(balance.total)
                            available_amount = float(balance.available)
                            locked_amount = total_amount - available_amount
                            
                            portfolio_holdings[symbol]["total"] += total_amount
                            portfolio_holdings[symbol]["available"] += available_amount
                            portfolio_holdings[symbol]["locked"] += locked_amount
                            portfolio_holdings[symbol]["exchanges"][exchange_name] = {
                                "total": total_amount,
                                "available": available_amount,
                                "locked": locked_amount
                            }
                            
                            symbol_value = trading_api.get_portfolio_value(exchange_manager, symbol=symbol)
                            if symbol_value:
                                portfolio_by_symbol[symbol] = float(symbol_value)
                                
            except Exception as e:
                continue
        
        return {
            "total_portfolio_value_usd": total_portfolio_value,
            "portfolio_by_exchange": portfolio_by_exchange,
            "portfolio_by_symbol": portfolio_by_symbol,
            "portfolio_holdings": portfolio_holdings
        }
    except Exception as e:
        return {"error": str(e), "total_portfolio_value_usd": 0.0}


def get_trading_metrics():
    """Get trading and order metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_open_orders": 0}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_open_orders": 0}
            
        total_open_orders = 0
        orders_by_exchange = {}
        orders_by_symbol = {}
        orders_by_side = {"buy": 0, "sell": 0}
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                
                # Get open orders
                open_orders = trading_api.get_open_orders(exchange_manager)
                if open_orders:
                    exchange_order_count = len(open_orders)
                    total_open_orders += exchange_order_count
                    orders_by_exchange[exchange_name] = exchange_order_count
                    
                    # Count orders by symbol and side
                    for order in open_orders:
                        symbol = getattr(order, 'symbol', 'unknown')
                        side = getattr(order, 'side', None)
                        
                        orders_by_symbol[symbol] = orders_by_symbol.get(symbol, 0) + 1
                        if side and hasattr(side, 'name'):
                            side_name = side.name.lower()
                            if side_name in orders_by_side:
                                orders_by_side[side_name] += 1
                            
            except Exception as e:
                continue
        
        return {
            "total_open_orders": total_open_orders,
            "orders_by_exchange": orders_by_exchange,
            "orders_by_symbol": orders_by_symbol,
            "orders_by_side": orders_by_side
        }
    except Exception as e:
        return {"error": str(e), "total_open_orders": 0}


def get_strategy_metrics():
    """Get strategy performance metrics"""
    try:
        # Get bot API to access evaluators
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_strategies": 0, "enabled_strategies": 0, "strategies": []}
            
        evaluators = bot_api.get_evaluators()
        if not evaluators:
            return {"error": "No evaluators available", "total_strategies": 0, "enabled_strategies": 0, "strategies": []}
            
        strategies = []
        
        for evaluator in evaluators:
            try:
                strategy_name = evaluator.get_name()
                strategies.append({
                    "name": strategy_name,
                    "enabled": getattr(evaluator, 'enabled', False),
                    "eval_note": getattr(evaluator, 'eval_note', 0),
                    "type": getattr(evaluator, 'get_evaluator_type', lambda: 'unknown')()
                })
            except Exception as e:
                strategies.append({
                    "name": str(evaluator),
                    "enabled": False,
                    "eval_note": 0,
                    "type": "unknown",
                    "error": str(e)
                })
        
        return {
            "total_strategies": len(strategies),
            "enabled_strategies": len([s for s in strategies if s.get("enabled", False)]),
            "strategies": strategies
        }
    except Exception as e:
        return {"error": str(e), "total_strategies": 0, "enabled_strategies": 0, "strategies": []}


def get_performance_metrics():
    """Get performance and risk metrics"""
    try:
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"total_trades": 0, "total_volume_usd": 0.0, "total_fees_usd": 0.0, "pnl_usd": 0.0}
        
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"total_trades": 0, "total_volume_usd": 0.0, "total_fees_usd": 0.0, "pnl_usd": 0.0}
        
        total_trades = 0
        total_volume = 0.0
        total_fees = 0.0
        
        for exchange_manager in exchange_managers:
            try:
                trades = trading_api.get_trade_history(exchange_manager)
                total_trades += len(trades)
                
                for trade in trades:
                    try:
                        total_volume += float(trade.total_cost)
                        if trade.fee:
                            total_fees += float(trade.fee.get('cost', 0))
                    except Exception:
                        continue
            except Exception:
                continue
        
        return {
            "total_trades": total_trades,
            "total_volume_usd": total_volume,
            "total_fees_usd": total_fees,
            "pnl_usd": 0.0,  # Would need PnL calculation
            "max_drawdown_percent": 0.0,
            "sharpe_ratio": 0.0,
            "volatility": 0.0
        }
    except Exception as e:
        return {"error": str(e), "total_trades": 0}


def get_orders_data():
    """Get all open orders data"""
    try:
        orders_data = []
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return []
        
        exchange_managers = bot_api.get_exchange_managers()
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = trading_api.get_exchange_name(exchange_manager)
                open_orders = trading_api.get_open_orders(exchange_manager)
                
                for order in open_orders:
                    try:
                        orders_data.append({
                            "exchange": exchange_name,
                            "symbol": order.symbol,
                            "order_id": order.order_id,
                            "order_type": order.order_type.name if hasattr(order.order_type, 'name') else str(order.order_type),
                            "side": order.side.name if hasattr(order.side, 'name') else str(order.side),
                            "price": float(order.origin_price),
                            "quantity": float(order.origin_quantity),
                            "filled": float(order.filled_quantity) if hasattr(order, 'filled_quantity') else 0,
                            "status": order.status.name if hasattr(order.status, 'name') else str(order.status),
                            "timestamp": float(order.creation_time) if hasattr(order, 'creation_time') else 0,
                            "is_simulated": trading_api.is_trader_simulated(exchange_manager)
                        })
                    except Exception:
                        continue
            except Exception:
                continue
        
        return orders_data
    except Exception:
        return []


def get_trades_data():
    """Get all trades history data - uses the same method as the regular trades page"""
    try:
        # Use the same function that the regular /api/trades endpoint uses
        # This ensures consistency with what the Trades History page shows
        all_trades = trading_models.get_all_trades_data()
        
        # Convert to the format expected by the metrics dashboard
        trades_data = []
        for trade in all_trades:
            try:
                trades_data.append({
                    "exchange": trade.get("exchange", "N/A"),
                    "symbol": trade.get("symbol", "N/A"),
                    "trade_id": trade.get("id", "N/A"),
                    "order_id": None,  # Not in the standard trade data
                    "side": trade.get("type", "N/A"),
                    "price": float(trade.get("price", 0)),
                    "quantity": float(trade.get("amount", 0)),
                    "cost": float(trade.get("cost", 0)),
                    "fee_cost": float(trade.get("fee_cost", 0)),
                    "fee_currency": trade.get("fee_currency", ""),
                    "timestamp": float(trade.get("time", 0)),
                    "is_simulated": trade.get("SoR", "") == "Simulated"
                })
            except Exception as e:
                # Log the error but continue
                import octobot_commons.logging as commons_logging
                commons_logging.get_logger("MetricsController").debug(f"Error processing trade: {e}")
                continue
        
        return trades_data
    except Exception as e:
        import octobot_commons.logging as commons_logging
        commons_logging.get_logger("MetricsController").error(f"Error in get_trades_data: {e}")
        return []


def get_positions_data():
    """Get all open positions data (for futures trading)"""
    try:
        positions_data = []
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return []
        
        exchange_managers = bot_api.get_exchange_managers()
        
        for exchange_manager in exchange_managers:
            try:
                if not exchange_manager.is_future:
                    continue
                
                exchange_name = trading_api.get_exchange_name(exchange_manager)
                positions = trading_api.get_positions(exchange_manager)
                
                for position in positions:
                    try:
                        if position.is_idle():
                            continue
                        
                        positions_data.append({
                            "exchange": exchange_name,
                            "symbol": position.symbol,
                            "side": position.side.value if hasattr(position.side, 'value') else str(position.side),
                            "size": float(position.size),
                            "value": float(position.value) if hasattr(position, 'value') else 0,
                            "entry_price": float(position.entry_price) if hasattr(position, 'entry_price') else 0,
                            "liquidation_price": float(position.liquidation_price) if hasattr(position, 'liquidation_price') else 0,
                            "unrealized_pnl": float(position.unrealized_pnl) if hasattr(position, 'unrealized_pnl') else 0,
                            "margin": float(position.margin) if hasattr(position, 'margin') else 0,
                            "is_simulated": trading_api.is_trader_simulated(exchange_manager)
                        })
                    except Exception:
                        continue
            except Exception:
                continue
        
        return positions_data
    except Exception:
        return []


def get_profitability_data():
    """Get overall profitability statistics"""
    try:
        profitability_data = {}
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {}
        
        exchange_managers = bot_api.get_exchange_managers()
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = trading_api.get_exchange_name(exchange_manager)
                profitability, profitability_percent = trading_api.get_profitability_stats(exchange_manager)
                
                profitability_data[exchange_name] = {
                    "profitability": float(profitability),
                    "profitability_percent": float(profitability_percent),
                    "is_simulated": trading_api.is_trader_simulated(exchange_manager)
                }
            except Exception:
                continue
        
        return profitability_data
    except Exception:
        return {}


def get_pnl_history_data():
    """Get PNL history from trading modes that support it
    
    NOTE: PNL history is only available for trading modes with SUPPORTS_PNL_HISTORY = True
    Examples: Grid Trading, Dip Analyser, Spot Perp Basis Trading, Triangular Arbitrage, XEMM Hedger
    """
    try:
        pnl_data = []
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return []
        
        exchange_managers = bot_api.get_exchange_managers()
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = trading_api.get_exchange_name(exchange_manager)
                
                # Get completed PNL history from trading modes that support it
                # Use the same approach as the web interface models
                pnl_history = trading_api.get_completed_pnl_history(
                    exchange_manager,
                    quote=None,  # All quote currencies
                    symbol=None,  # All symbols
                    since=None   # All time
                )
                
                for pnl_entry in pnl_history:
                    try:
                        # Validate PNL entry (same as web interface does)
                        if not _is_valid_pnl(pnl_entry):
                            continue
                        
                        # Use the proper API methods
                        entry_time = pnl_entry.get_entry_time()
                        close_time = pnl_entry.get_close_time()
                        pnl_value, pnl_percent = pnl_entry.get_profits()
                        
                        # Get symbol from entries
                        symbol = 'N/A'
                        if pnl_entry.entries and len(pnl_entry.entries) > 0:
                            symbol = pnl_entry.entries[0].symbol
                        
                        pnl_data.append({
                            "exchange": exchange_name,
                            "symbol": symbol,
                            "entry_time": float(entry_time),
                            "exit_time": float(close_time),
                            "pnl": float(pnl_value),
                            "pnl_currency": pnl_entry.currency,
                            "trades_count": len(pnl_entry.entries) + len(pnl_entry.closes),
                            "is_simulated": trading_api.is_trader_simulated(exchange_manager)
                        })
                    except Exception as e:
                        # Log but continue
                        import octobot_commons.logging as commons_logging
                        commons_logging.get_logger("MetricsController").debug(f"Error processing PNL entry: {e}")
                        continue
                        
            except Exception as e:
                # Log but continue
                import octobot_commons.logging as commons_logging
                commons_logging.get_logger("MetricsController").debug(f"Error fetching PNL for {exchange_name}: {e}")
                continue
        
        return pnl_data
    except Exception as e:
        import octobot_commons.logging as commons_logging
        commons_logging.get_logger("MetricsController").error(f"Error in get_pnl_history_data: {e}")
        return []


def _is_valid_pnl(pnl):
    """Check if a PNL entry is valid (has entry and close times)"""
    try:
        return pnl.get_entry_time() and pnl.get_close_time()
    except trading_errors.IncompletePNLError:
        return False
    except Exception:
        return False
