# Custom Metrics Page Controller for OctoBot Web Interface

import flask
import json
import time
import asyncio
from datetime import datetime

import octobot_services.interfaces.util as interfaces_util
import octobot_trading.api as trading_api
import octobot_evaluators.api as evaluators_api
import tentacles.Services.Interfaces.web_interface.login as login
import tentacles.Services.Interfaces.web_interface.util as util


def register(blueprint):
    @blueprint.route("/metrics", methods=['GET'])
    @login.login_required_when_activated
    def metrics():
        """Custom metrics dashboard page"""
        try:
            # Get comprehensive metrics data
            metrics_data = get_comprehensive_metrics()
            return flask.render_template('metrics.html', metrics=metrics_data)
        except Exception as e:
            return util.get_rest_reply(f"Error loading metrics: {str(e)}", 500)

    @blueprint.route("/api/metrics", methods=['GET'])
    @login.login_required_when_activated
    def api_metrics():
        """API endpoint for metrics data in JSON format"""
        try:
            metrics_data = get_comprehensive_metrics()
            return flask.jsonify(metrics_data)
        except Exception as e:
            return flask.jsonify({"error": str(e)}), 500

    @blueprint.route("/api/metrics/prometheus", methods=['GET'])
    @login.login_required_when_activated
    def api_metrics_prometheus():
        """API endpoint for metrics data in Prometheus format for scraping"""
        try:
            metrics_data = get_comprehensive_metrics()
            
            # Convert to Prometheus format
            prometheus_lines = []
            
            # System metrics
            system = metrics_data.get("system", {})
            prometheus_lines.append(f"# HELP octobot_system_cpu_usage_percent CPU usage percentage")
            prometheus_lines.append(f"# TYPE octobot_system_cpu_usage_percent gauge")
            prometheus_lines.append(f"octobot_system_cpu_usage_percent {system.get('cpu_usage_percent', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_system_memory_usage_mb Memory usage in MB")
            prometheus_lines.append(f"# TYPE octobot_system_memory_usage_mb gauge")
            prometheus_lines.append(f"octobot_system_memory_usage_mb {system.get('memory_usage_mb', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_system_uptime_seconds System uptime in seconds")
            prometheus_lines.append(f"# TYPE octobot_system_uptime_seconds counter")
            prometheus_lines.append(f"octobot_system_uptime_seconds {system.get('uptime_seconds', 0)}")
            
            # Exchange metrics
            exchanges = metrics_data.get("exchanges", {})
            prometheus_lines.append(f"# HELP octobot_exchange_total Total number of exchanges")
            prometheus_lines.append(f"# TYPE octobot_exchange_total gauge")
            prometheus_lines.append(f"octobot_exchange_total {exchanges.get('total_exchanges', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_exchange_connected Number of connected exchanges")
            prometheus_lines.append(f"# TYPE octobot_exchange_connected gauge")
            prometheus_lines.append(f"octobot_exchange_connected {exchanges.get('connected_exchanges', 0)}")
            
            for exchange in exchanges.get("exchanges", []):
                exchange_name = exchange.get("name", "unknown")
                prometheus_lines.append(f"# HELP octobot_exchange_portfolio_value_usd Portfolio value in USD")
                prometheus_lines.append(f"# TYPE octobot_exchange_portfolio_value_usd gauge")
                prometheus_lines.append(f'octobot_exchange_portfolio_value_usd{{exchange="{exchange_name}"}} {exchange.get("portfolio_value_usd", 0)}')
            
            # Portfolio metrics
            portfolio = metrics_data.get("portfolio", {})
            prometheus_lines.append(f"# HELP octobot_portfolio_total_value_usd Total portfolio value in USD")
            prometheus_lines.append(f"# TYPE octobot_portfolio_total_value_usd gauge")
            prometheus_lines.append(f"octobot_portfolio_total_value_usd {portfolio.get('total_portfolio_value_usd', 0)}")
            
            # Trading metrics
            trading = metrics_data.get("trading", {})
            prometheus_lines.append(f"# HELP octobot_trading_open_orders Total number of open orders")
            prometheus_lines.append(f"# TYPE octobot_trading_open_orders gauge")
            prometheus_lines.append(f"octobot_trading_open_orders {trading.get('total_open_orders', 0)}")
            
            # Strategy metrics
            strategies = metrics_data.get("strategies", {})
            prometheus_lines.append(f"# HELP octobot_strategy_total Total number of strategies")
            prometheus_lines.append(f"# TYPE octobot_strategy_total gauge")
            prometheus_lines.append(f"octobot_strategy_total {strategies.get('total_strategies', 0)}")
            
            prometheus_lines.append(f"# HELP octobot_strategy_enabled Number of enabled strategies")
            prometheus_lines.append(f"# TYPE octobot_strategy_enabled gauge")
            prometheus_lines.append(f"octobot_strategy_enabled {strategies.get('enabled_strategies', 0)}")
            
            for strategy in strategies.get("strategies", []):
                strategy_name = strategy.get("name", "unknown")
                prometheus_lines.append(f"# HELP octobot_strategy_eval_note Strategy evaluation note")
                prometheus_lines.append(f"# TYPE octobot_strategy_eval_note gauge")
                prometheus_lines.append(f'octobot_strategy_eval_note{{strategy="{strategy_name}"}} {strategy.get("eval_note", 0)}')
            
            # Return raw text format for Prometheus
            return '\n'.join(prometheus_lines) + '\n'
            
        except Exception as e:
            return f"octobot_error 1\n", 500


def get_comprehensive_metrics():
    """Get comprehensive metrics data from OctoBot"""
    try:
        # Get all metrics with fallback to empty dicts
        system_metrics = get_system_metrics() or {}
        exchange_metrics = get_exchange_metrics() or {}
        portfolio_metrics = get_portfolio_metrics() or {}
        trading_metrics = get_trading_metrics() or {}
        strategy_metrics = get_strategy_metrics() or {}
        performance_metrics = get_performance_metrics() or {}
        
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "system": system_metrics,
            "exchanges": exchange_metrics,
            "portfolio": portfolio_metrics,
            "trading": trading_metrics,
            "strategies": strategy_metrics,
            "performance": performance_metrics
        }
        return metrics
    except Exception as e:
        return {
            "error": str(e), 
            "timestamp": datetime.now().isoformat(),
            "system": {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0},
            "exchanges": {"total_exchanges": 0, "connected_exchanges": 0, "exchanges": []},
            "portfolio": {"total_portfolio_value_usd": 0.0, "portfolio_by_exchange": {}, "portfolio_by_symbol": {}},
            "trading": {"total_open_orders": 0, "orders_by_exchange": {}, "orders_by_symbol": {}, "orders_by_side": {"buy": 0, "sell": 0}},
            "strategies": {"total_strategies": 0, "enabled_strategies": 0, "strategies": []},
            "performance": {"total_trades": 0, "total_volume_usd": 0.0, "total_fees_usd": 0.0, "pnl_usd": 0.0, "max_drawdown_percent": 0.0, "sharpe_ratio": 0.0, "volatility": 0.0}
        }


def get_system_metrics():
    """Get system performance metrics"""
    try:
        import psutil
        process = psutil.Process()
        return {
            "cpu_usage_percent": process.cpu_percent(),
            "memory_usage_mb": process.memory_info().rss / 1024 / 1024,
            "uptime_seconds": time.time() - process.create_time()
        }
    except ImportError:
        return {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0}
    except Exception:
        return {"cpu_usage_percent": 0, "memory_usage_mb": 0, "uptime_seconds": 0}


def get_exchange_metrics():
    """Get exchange connection and status metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}
            
        exchanges = []
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                is_connected = trading_api.is_exchange_connected(exchange_manager)
                
                # Get portfolio value for this exchange
                portfolio_value = trading_api.get_portfolio_value(exchange_manager)
                
                exchanges.append({
                    "name": exchange_name,
                    "connected": is_connected,
                    "portfolio_value_usd": float(portfolio_value) if portfolio_value else 0.0,
                    "type": getattr(exchange_manager, 'exchange_type', 'unknown')
                })
            except Exception as e:
                exchanges.append({
                    "name": str(exchange_manager),
                    "connected": False,
                    "portfolio_value_usd": 0.0,
                    "type": "unknown",
                    "error": str(e)
                })
        
        return {
            "total_exchanges": len(exchanges),
            "connected_exchanges": len([e for e in exchanges if e["connected"]]),
            "exchanges": exchanges
        }
    except Exception as e:
        return {"error": str(e), "total_exchanges": 0, "connected_exchanges": 0, "exchanges": []}


def get_portfolio_metrics():
    """Get portfolio value and balance metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_portfolio_value_usd": 0.0}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_portfolio_value_usd": 0.0}
            
        total_portfolio_value = 0.0
        portfolio_by_exchange = {}
        portfolio_by_symbol = {}
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                
                # Get total portfolio value
                portfolio_value = trading_api.get_portfolio_value(exchange_manager)
                if portfolio_value:
                    portfolio_float = float(portfolio_value)
                    total_portfolio_value += portfolio_float
                    portfolio_by_exchange[exchange_name] = portfolio_float
                
                # Get portfolio by symbol
                portfolio = trading_api.get_portfolio(exchange_manager)
                if portfolio:
                    for symbol, balance in portfolio.items():
                        if balance and balance.total > 0:
                            symbol_value = trading_api.get_portfolio_value(exchange_manager, symbol=symbol)
                            if symbol_value:
                                portfolio_by_symbol[symbol] = float(symbol_value)
                                
            except Exception as e:
                continue
        
        return {
            "total_portfolio_value_usd": total_portfolio_value,
            "portfolio_by_exchange": portfolio_by_exchange,
            "portfolio_by_symbol": portfolio_by_symbol
        }
    except Exception as e:
        return {"error": str(e), "total_portfolio_value_usd": 0.0}


def get_trading_metrics():
    """Get trading and order metrics"""
    try:
        # Get bot API to access exchange managers
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_open_orders": 0}
            
        exchange_managers = bot_api.get_exchange_managers()
        if not exchange_managers:
            return {"error": "No exchange managers available", "total_open_orders": 0}
            
        total_open_orders = 0
        orders_by_exchange = {}
        orders_by_symbol = {}
        orders_by_side = {"buy": 0, "sell": 0}
        
        for exchange_manager in exchange_managers:
            try:
                exchange_name = exchange_manager.exchange_name
                
                # Get open orders
                open_orders = trading_api.get_open_orders(exchange_manager)
                if open_orders:
                    exchange_order_count = len(open_orders)
                    total_open_orders += exchange_order_count
                    orders_by_exchange[exchange_name] = exchange_order_count
                    
                    # Count orders by symbol and side
                    for order in open_orders:
                        symbol = order.get('symbol', 'unknown')
                        side = order.get('side', 'unknown')
                        
                        orders_by_symbol[symbol] = orders_by_symbol.get(symbol, 0) + 1
                        if side in orders_by_side:
                            orders_by_side[side] += 1
                            
            except Exception as e:
                continue
        
        return {
            "total_open_orders": total_open_orders,
            "orders_by_exchange": orders_by_exchange,
            "orders_by_symbol": orders_by_symbol,
            "orders_by_side": orders_by_side
        }
    except Exception as e:
        return {"error": str(e), "total_open_orders": 0}


def get_strategy_metrics():
    """Get strategy performance metrics"""
    try:
        # Get bot API to access evaluators
        bot_api = interfaces_util.get_bot_api()
        if not bot_api:
            return {"error": "Bot API not available", "total_strategies": 0, "enabled_strategies": 0, "strategies": []}
            
        evaluators = bot_api.get_evaluators()
        if not evaluators:
            return {"error": "No evaluators available", "total_strategies": 0, "enabled_strategies": 0, "strategies": []}
            
        strategies = []
        
        for evaluator in evaluators:
            try:
                strategy_name = evaluator.get_name()
                strategies.append({
                    "name": strategy_name,
                    "enabled": getattr(evaluator, 'enabled', False),
                    "eval_note": getattr(evaluator, 'eval_note', 0),
                    "type": getattr(evaluator, 'get_evaluator_type', lambda: 'unknown')()
                })
            except Exception as e:
                strategies.append({
                    "name": str(evaluator),
                    "enabled": False,
                    "eval_note": 0,
                    "type": "unknown",
                    "error": str(e)
                })
        
        return {
            "total_strategies": len(strategies),
            "enabled_strategies": len([s for s in strategies if s.get("enabled", False)]),
            "strategies": strategies
        }
    except Exception as e:
        return {"error": str(e), "total_strategies": 0, "enabled_strategies": 0, "strategies": []}


def get_performance_metrics():
    """Get performance and risk metrics"""
    try:
        # Basic performance metrics
        return {
            "total_trades": 0,  # Would need trade history
            "total_volume_usd": 0.0,  # Would need trade history
            "total_fees_usd": 0.0,  # Would need trade history
            "pnl_usd": 0.0,  # Would need PnL calculation
            "max_drawdown_percent": 0.0,  # Would need historical data
            "sharpe_ratio": 0.0,  # Would need returns calculation
            "volatility": 0.0  # Would need price history
        }
    except Exception as e:
        return {"error": str(e)}
